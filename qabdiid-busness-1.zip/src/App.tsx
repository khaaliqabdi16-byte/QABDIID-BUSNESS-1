/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Layout } from './components/Layout.tsx';
import { LoginPage } from './pages/LoginPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { PosPage } from './pages/PosPage.tsx';
import { SalesPage } from './pages/SalesPage.tsx';
import { PurchasesPage } from './pages/PurchasesPage.tsx';
import { CatalogPage } from './pages/CatalogPage.tsx';
import { InventoryPage } from './pages/InventoryPage.tsx';
import { PeoplePage } from './pages/PeoplePage.tsx';
import { DebtsPage } from './pages/DebtsPage.tsx';
import { ExpensesPage } from './pages/ExpensesPage.tsx';
import { AccountingPage } from './pages/AccountingPage.tsx';
import { CurrenciesPage } from './pages/CurrenciesPage.tsx';
import { ReportsPage } from './pages/ReportsPage.tsx';
import { UsersPage } from './pages/UsersPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';

function ErpWorkspace() {
  const { user, authLoading, activePage, t } = useApp();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#0B1F4D] dark:text-[#06B6D4] font-medium">
        {t('loading')}
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardPage />;
      case 'pos':
        return <PosPage />;
      case 'sales':
        return <SalesPage />;
      case 'purchases':
        return <PurchasesPage />;
      case 'catalog':
        return <CatalogPage />;
      case 'inventory':
        return <InventoryPage />;
      case 'people':
        return <PeoplePage />;
      case 'debts':
        return <DebtsPage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'accounting':
        return <AccountingPage />;
      case 'currencies':
        return <CurrenciesPage />;
      case 'reports':
        return <ReportsPage />;
      case 'users':
        return <UsersPage />;
      case 'settings':
        return <SettingsPage />;
      case 'profile':
        return <ProfilePage />;
      default:
        return <DashboardPage />;
    }
  };

  return <Layout>{renderPage()}</Layout>;
}

export default function App() {
  return (
    <AppProvider>
      <ErpWorkspace />
    </AppProvider>
  );
}
