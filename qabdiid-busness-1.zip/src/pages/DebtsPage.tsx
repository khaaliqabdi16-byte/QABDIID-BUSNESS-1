import React, { useEffect, useState, useCallback } from 'react';
import { CreditCard, FileText, Download, Search, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { exportExcel, exportReportPdf, formatMoney } from '../utils/export.ts';
import { CurrencyCode, Customer, Supplier } from '../types/erp.ts';

interface UnpaidSale {
  id: number;
  invoice_number: string;
  sale_date: string;
  customer_id: number;
  customer_name: string;
  customer_phone: string;
  currency: CurrencyCode;
  exchange_rate: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  status: string;
}

interface UnpaidPurchase {
  id: number;
  purchase_number: string;
  purchase_date: string;
  supplier_id: number;
  supplier_name: string;
  supplier_phone: string;
  currency: CurrencyCode;
  exchange_rate: number;
  grand_total: number;
  paid_amount: number;
  balance_amount: number;
  status: string;
}

interface PaymentHistoryRow {
  party_type: string;
  party_name: string;
  amount: number;
  currency: string;
  amount_etb: number;
  payment_method: string;
  notes: string;
  created_by: string;
  created_at: string;
}

interface DebtsResponse {
  customerDebts: Customer[];
  supplierDebts: Supplier[];
  unpaidSales: UnpaidSale[];
  unpaidPurchases: UnpaidPurchase[];
  paymentHistory: PaymentHistoryRow[];
}

export function DebtsPage() {
  const { t, settings, currencies, hasPermission, showToast, refreshNotifications } = useApp();
  const [tab, setTab] = useState<'customers' | 'suppliers' | 'history'>('customers');
  const [data, setData] = useState<DebtsResponse | null>(null);
  const [search, setSearch] = useState('');

  const [payModal, setPayModal] = useState<{
    type: 'customer' | 'supplier';
    partyId: number;
    name: string;
    balance: number;
    saleId?: number;
    purchaseId?: number;
    defaultCurrency: CurrencyCode;
  } | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payCurrency, setPayCurrency] = useState<CurrencyCode>('ETB');
  const [payMethod, setPayMethod] = useState('Cash');
  const [payNotes, setPayNotes] = useState('');

  const [statement, setStatement] = useState<{
    name: string;
    records: Array<Record<string, unknown>>;
    payments: Array<Record<string, unknown>>;
  } | null>(null);

  const loadDebts = useCallback(async () => {
    try {
      const res = await apiFetch<DebtsResponse>('/api/debts');
      setData(res);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load debts', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadDebts();
  }, [loadDebts]);

  const totalCustomerDebt = (data?.customerDebts || []).reduce((s, c) => s + c.outstanding_balance, 0);
  const totalSupplierDebt = (data?.supplierDebts || []).reduce((s, sup) => s + sup.outstanding_balance, 0);
  const netPosition = totalCustomerDebt - totalSupplierDebt;

  const q = search.trim().toLowerCase();
  const filteredCustomers = (data?.customerDebts || []).filter(
    (c) => !q || c.full_name.toLowerCase().includes(q) || (c.phone || '').toLowerCase().includes(q)
  );
  const filteredUnpaidSales = (data?.unpaidSales || []).filter(
    (s) => !q || s.invoice_number.toLowerCase().includes(q) || s.customer_name.toLowerCase().includes(q)
  );
  const filteredSuppliers = (data?.supplierDebts || []).filter(
    (s) => !q || s.business_name.toLowerCase().includes(q) || (s.phone || '').toLowerCase().includes(q)
  );
  const filteredUnpaidPurchases = (data?.unpaidPurchases || []).filter(
    (p) => !q || p.purchase_number.toLowerCase().includes(q) || p.supplier_name.toLowerCase().includes(q)
  );
  const filteredHistory = (data?.paymentHistory || []).filter(
    (h) => !q || h.party_name.toLowerCase().includes(q) || (h.notes || '').toLowerCase().includes(q)
  );

  const submitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModal) return;
    try {
      const endpoint =
        payModal.type === 'customer' ? `/api/customers/${payModal.partyId}/pay` : `/api/suppliers/${payModal.partyId}/pay`;
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({
          sale_id: payModal.saleId,
          purchase_id: payModal.purchaseId,
          amount: Number(payAmount),
          currency: payCurrency,
          payment_method: payMethod,
          notes: payNotes,
        }),
      });
      setPayModal(null);
      setPayNotes('');
      showToast('Debt payment recorded', 'success');
      await Promise.all([loadDebts(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Payment failed', 'error');
    }
  };

  const viewStatement = async (type: 'customer' | 'supplier', id: number, name: string) => {
    try {
      if (type === 'customer') {
        const res = await apiFetch<{ sales: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(
          `/api/customers/${id}/statement`
        );
        setStatement({ name, records: res.sales, payments: res.payments });
      } else {
        const res = await apiFetch<{ purchases: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(
          `/api/suppliers/${id}/statement`
        );
        setStatement({ name, records: res.purchases, payments: res.payments });
      }
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load statement', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Debt Summary KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{t('customerDebt')}</div>
          <div className="text-xl font-bold font-mono-num text-amber-700 dark:text-amber-400 mt-1.5">
            {formatMoney(totalCustomerDebt, 'ETB')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {data?.customerDebts.length || 0} customer(s) · {data?.unpaidSales.length || 0} invoice(s)
          </div>
        </div>

        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{t('supplierDebt')}</div>
          <div className="text-xl font-bold font-mono-num text-red-600 dark:text-red-400 mt-1.5">
            {formatMoney(totalSupplierDebt, 'ETB')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {data?.supplierDebts.length || 0} supplier(s) · {data?.unpaidPurchases.length || 0} order(s)
          </div>
        </div>

        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{t('netDebtPosition')}</div>
          <div className={`text-xl font-bold font-mono-num mt-1.5 ${netPosition >= 0 ? 'text-[#2563EB] dark:text-[#06B6D4]' : 'text-red-600 dark:text-red-400'}`}>
            {formatMoney(netPosition, 'ETB')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Receivables − Payables (ETB)</div>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setTab('customers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              tab === 'customers' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('customerDebt')} ({filteredCustomers.length})
          </button>
          <button
            onClick={() => setTab('suppliers')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              tab === 'suppliers' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('supplierDebt')} ({filteredSuppliers.length})
          </button>
          <button
            onClick={() => setTab('history')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              tab === 'history' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
            }`}
          >
            {t('debtPaymentHistory')} ({filteredHistory.length})
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, phone, invoice..."
              className="pl-8 pr-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs w-56"
            />
          </div>
          <button
            onClick={() => {
              if (tab === 'customers') exportExcel('qabdiid_customer_debts', filteredCustomers as unknown as Record<string, unknown>[]);
              else if (tab === 'suppliers') exportExcel('qabdiid_supplier_debts', filteredSuppliers as unknown as Record<string, unknown>[]);
              else exportExcel('qabdiid_debt_payments', filteredHistory as unknown as Record<string, unknown>[]);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" /> {t('exportExcel')}
          </button>
        </div>
      </div>

      {/* Customer Debts Tab */}
      {tab === 'customers' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              {t('customerDebt')}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">{t('customer')}</th>
                    <th className="text-left px-4 py-3 font-medium">Phone</th>
                    <th className="text-right px-4 py-3 font-medium">Total Purchases</th>
                    <th className="text-right px-4 py-3 font-medium">Total Paid</th>
                    <th className="text-right px-4 py-3 font-medium">Outstanding Balance</th>
                    <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCustomers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    filteredCustomers.map((c) => (
                      <tr key={c.id}>
                        <td className="px-4 py-3 font-semibold">{c.full_name}</td>
                        <td className="px-4 py-3 text-slate-500">{c.phone || '-'}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(c.total_purchases, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(c.total_paid, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num font-bold text-amber-700 dark:text-amber-400">
                          {formatMoney(c.outstanding_balance, 'ETB')}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => viewStatement('customer', c.id, c.full_name)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                              title={t('viewStatement')}
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                            {hasPermission('people.manage') && (
                              <button
                                onClick={() => {
                                  setPayModal({
                                    type: 'customer',
                                    partyId: c.id,
                                    name: c.full_name,
                                    balance: c.outstanding_balance,
                                    defaultCurrency: 'ETB',
                                  });
                                  setPayCurrency('ETB');
                                  setPayAmount(String(c.outstanding_balance));
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                              >
                                <CreditCard className="w-3.5 h-3.5" /> {t('recordPayment')}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              {t('unpaidInvoices')}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">Invoice</th>
                    <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                    <th className="text-left px-4 py-3 font-medium">{t('customer')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('total')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('amountPaid')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredUnpaidSales.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    filteredUnpaidSales.map((s) => (
                      <tr key={s.id}>
                        <td className="px-4 py-3 font-mono-num font-semibold">{s.invoice_number}</td>
                        <td className="px-4 py-3 font-mono-num text-slate-500">{s.sale_date}</td>
                        <td className="px-4 py-3">{s.customer_name}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(s.grand_total, s.currency)}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(s.paid_amount, s.currency)}</td>
                        <td className="px-4 py-3 text-right font-mono-num font-bold text-amber-700 dark:text-amber-400">
                          {formatMoney(s.balance_amount, s.currency)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {hasPermission('people.manage') && (
                            <button
                              onClick={() => {
                                setPayModal({
                                  type: 'customer',
                                  partyId: s.customer_id,
                                  saleId: s.id,
                                  name: `${s.customer_name} (${s.invoice_number})`,
                                  balance: s.balance_amount,
                                  defaultCurrency: s.currency,
                                });
                                setPayCurrency(s.currency);
                                setPayAmount(String(s.balance_amount));
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                            >
                              <CreditCard className="w-3.5 h-3.5" /> {t('recordPayment')}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Supplier Debts Tab */}
      {tab === 'suppliers' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              {t('supplierDebt')}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">{t('supplier')}</th>
                    <th className="text-left px-4 py-3 font-medium">Phone</th>
                    <th className="text-right px-4 py-3 font-medium">Total Purchases</th>
                    <th className="text-right px-4 py-3 font-medium">Total Paid</th>
                    <th className="text-right px-4 py-3 font-medium">Outstanding Balance</th>
                    <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredSuppliers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    filteredSuppliers.map((sup) => (
                      <tr key={sup.id}>
                        <td className="px-4 py-3 font-semibold">{sup.business_name}</td>
                        <td className="px-4 py-3 text-slate-500">{sup.phone || '-'}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(sup.total_purchases, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(sup.total_paid, 'ETB')}</td>
                        <td className="px-4 py-3 text-right font-mono-num font-bold text-red-600 dark:text-red-400">
                          {formatMoney(sup.outstanding_balance, 'ETB')}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => viewStatement('supplier', sup.id, sup.business_name)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700"
                              title={t('viewStatement')}
                            >
                              <FileText className="w-3.5 h-3.5" />
                            </button>
                            {hasPermission('people.manage') && (
                              <button
                                onClick={() => {
                                  setPayModal({
                                    type: 'supplier',
                                    partyId: sup.id,
                                    name: sup.business_name,
                                    balance: sup.outstanding_balance,
                                    defaultCurrency: 'ETB',
                                  });
                                  setPayCurrency('ETB');
                                  setPayAmount(String(sup.outstanding_balance));
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                              >
                                <CreditCard className="w-3.5 h-3.5" /> {t('recordPayment')}
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              {t('unpaidPurchases')}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">Purchase #</th>
                    <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                    <th className="text-left px-4 py-3 font-medium">{t('supplier')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('total')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('amountPaid')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')}</th>
                    <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredUnpaidPurchases.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    filteredUnpaidPurchases.map((p) => (
                      <tr key={p.id}>
                        <td className="px-4 py-3 font-mono-num font-semibold">{p.purchase_number}</td>
                        <td className="px-4 py-3 font-mono-num text-slate-500">{p.purchase_date}</td>
                        <td className="px-4 py-3">{p.supplier_name}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(p.grand_total, p.currency)}</td>
                        <td className="px-4 py-3 text-right font-mono-num">{formatMoney(p.paid_amount, p.currency)}</td>
                        <td className="px-4 py-3 text-right font-mono-num font-bold text-red-600 dark:text-red-400">
                          {formatMoney(p.balance_amount, p.currency)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {hasPermission('people.manage') && (
                            <button
                              onClick={() => {
                                setPayModal({
                                  type: 'supplier',
                                  partyId: p.supplier_id,
                                  purchaseId: p.id,
                                  name: `${p.supplier_name} (${p.purchase_number})`,
                                  balance: p.balance_amount,
                                  defaultCurrency: p.currency,
                                });
                                setPayCurrency(p.currency);
                                setPayAmount(String(p.balance_amount));
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                            >
                              <CreditCard className="w-3.5 h-3.5" /> {t('recordPayment')}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Payment History Tab */}
      {tab === 'history' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">Type</th>
                  <th className="text-left px-4 py-3 font-medium">Party</th>
                  <th className="text-left px-4 py-3 font-medium">{t('paymentMethod')}</th>
                  <th className="text-right px-4 py-3 font-medium">Amount</th>
                  <th className="text-right px-4 py-3 font-medium">ETB Equivalent</th>
                  <th className="text-left px-4 py-3 font-medium">Notes</th>
                  <th className="text-left px-4 py-3 font-medium">User</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((h, i) => (
                    <tr key={i}>
                      <td className="px-4 py-2.5 font-mono-num text-slate-500">{h.created_at}</td>
                      <td className="px-4 py-2.5 font-medium">{h.party_type}</td>
                      <td className="px-4 py-2.5 font-semibold">{h.party_name}</td>
                      <td className="px-4 py-2.5">{h.payment_method}</td>
                      <td className="px-4 py-2.5 text-right font-mono-num">{formatMoney(h.amount, h.currency)}</td>
                      <td className="px-4 py-2.5 text-right font-mono-num font-semibold">{formatMoney(h.amount_etb, 'ETB')}</td>
                      <td className="px-4 py-2.5 text-slate-500">{h.notes || '-'}</td>
                      <td className="px-4 py-2.5 text-slate-500">{h.created_by}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {payModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={submitPayment} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-3 text-xs erp-card">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">{t('recordPayment')} · {payModal.name}</h3>
              <button type="button" onClick={() => setPayModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-slate-500">
              Balance: <span className="font-mono-num font-semibold">{formatMoney(payModal.balance, payModal.defaultCurrency)}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                step="0.01"
                min={0.01}
                required
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
              />
              <select
                value={payCurrency}
                onChange={(e) => setPayCurrency(e.target.value as CurrencyCode)}
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                {currencies.map((c) => (
                  <option key={c.code} value={c.code}>{c.code}</option>
                ))}
              </select>
            </div>
            <select
              value={payMethod}
              onChange={(e) => setPayMethod(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="Cash">{t('cash')}</option>
              <option value="Bank Transfer">{t('bankTransfer')}</option>
              <option value="Mobile Money">{t('mobileMoney')}</option>
            </select>
            <input
              type="text"
              placeholder="Notes"
              value={payNotes}
              onChange={(e) => setPayNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
            />
            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setPayModal(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Statement Modal */}
      {statement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">Debt Statement · {statement.name}</h3>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => exportReportPdf(`Debt Statement - ${statement.name}`, statement.records, settings)}
                  className="px-3 py-1.5 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium transition-colors"
                >
                  {t('exportPdf')}
                </button>
                <button onClick={() => setStatement(null)}>
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
            <table className="w-full border border-slate-200 dark:border-slate-800">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                  <th className="text-left p-2">Ref</th>
                  <th className="text-left p-2">Date</th>
                  <th className="text-right p-2">Total</th>
                  <th className="text-right p-2">Paid</th>
                  <th className="text-right p-2">Balance</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {statement.records.map((r, i) => (
                  <tr key={i}>
                    <td className="p-2 font-mono-num">{String(r.invoice_number || r.purchase_number)}</td>
                    <td className="p-2 font-mono-num">{String(r.sale_date || r.purchase_date)}</td>
                    <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.grand_total), String(r.currency))}</td>
                    <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.paid_amount), String(r.currency))}</td>
                    <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.balance_amount), String(r.currency))}</td>
                    <td className="p-2">{String(r.status)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
