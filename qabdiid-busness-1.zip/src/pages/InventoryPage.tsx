import React, { useEffect, useState, useCallback } from 'react';
import { ArrowLeftRight, PlusCircle, MinusCircle, Building2, Search, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney } from '../utils/export.ts';
import { Product, Warehouse } from '../types/erp.ts';

interface MovementRow {
  id: number;
  product_name: string;
  sku: string;
  unit: string;
  warehouse_name: string;
  movement_type: string;
  quantity: number;
  unit_cost: number;
  reference_id: string;
  notes: string;
  created_by: string;
  created_at: string;
}

interface ValuationSummary {
  total_products: number;
  total_units: number;
  total_cost_value: number;
  total_retail_value: number;
  low_stock_count: number;
  out_of_stock_count?: number;
}

export function InventoryPage() {
  const { t, hasPermission, showToast, refreshNotifications, activeSubTab, setActiveSubTab } = useApp();
  const [tab, setTab] = useState<'stock' | 'low_stock'>(() => (activeSubTab === 'low_stock' ? 'low_stock' : 'stock'));

  useEffect(() => {
    if (activeSubTab === 'stock' || activeSubTab === 'low_stock') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const switchTab = (next: 'stock' | 'low_stock') => {
    setTab(next);
    setActiveSubTab(next);
  };

  const [products, setProducts] = useState<Product[]>([]);
  const [lowStockItems, setLowStockItems] = useState<Product[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [movements, setMovements] = useState<MovementRow[]>([]);
  const [summary, setSummary] = useState<ValuationSummary | null>(null);
  const [expiring, setExpiring] = useState<Array<{ id: number; name: string; sku: string; current_stock: number; unit: string; expiry_date: string }>>([]);
  const [search, setSearch] = useState('');

  const [adjProd, setAdjProd] = useState('');
  const [adjType, setAdjType] = useState<'IN' | 'OUT'>('IN');
  const [adjQty, setAdjQty] = useState('1');
  const [adjNotes, setAdjNotes] = useState('');

  const [trProd, setTrProd] = useState('');
  const [trFrom, setTrFrom] = useState('');
  const [trTo, setTrTo] = useState('');
  const [trQty, setTrQty] = useState('1');
  const [trNotes, setTrNotes] = useState('');

  const [whName, setWhName] = useState('');
  const [whLoc, setWhLoc] = useState('');

  const loadData = useCallback(async () => {
    try {
      const [pRes, lowRes, wRes, mRes, vRes] = await Promise.all([
        apiFetch<{ products: Product[] }>('/api/products?active=1'),
        apiFetch<{ items: Product[] }>('/api/inventory/low-stock'),
        apiFetch<{ warehouses: Warehouse[] }>('/api/warehouses'),
        apiFetch<{ movements: MovementRow[] }>('/api/inventory/movements'),
        apiFetch<{ summary: ValuationSummary; expiring: Array<{ id: number; name: string; sku: string; current_stock: number; unit: string; expiry_date: string }> }>('/api/inventory/valuation'),
      ]);
      setProducts(pRes.products);
      setLowStockItems(lowRes.items);
      setWarehouses(wRes.warehouses);
      setMovements(mRes.movements);
      setSummary(vRes.summary);
      setExpiring(vRes.expiring);
      if (!adjProd && pRes.products[0]) setAdjProd(String(pRes.products[0].id));
      if (!trProd && pRes.products[0]) setTrProd(String(pRes.products[0].id));
      if (!trFrom && wRes.warehouses[0]) setTrFrom(String(wRes.warehouses[0].id));
      if (!trTo && wRes.warehouses[1]) setTrTo(String(wRes.warehouses[1].id));
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load inventory', 'error');
    }
  }, [adjProd, trProd, trFrom, trTo, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const submitAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/inventory/adjust', {
        method: 'POST',
        body: JSON.stringify({
          product_id: Number(adjProd),
          adjustment_type: adjType,
          quantity: Number(adjQty),
          notes: adjNotes,
        }),
      });
      showToast('Stock adjusted', 'success');
      setAdjNotes('');
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Adjustment failed', 'error');
    }
  };

  const quickRestock = (productId: number) => {
    setAdjProd(String(productId));
    setAdjType('IN');
    setAdjQty('10');
    setAdjNotes('Quick restock from low stock alert');
    switchTab('stock');
  };

  const submitTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/inventory/transfer', {
        method: 'POST',
        body: JSON.stringify({
          product_id: Number(trProd),
          from_warehouse_id: Number(trFrom),
          to_warehouse_id: Number(trTo),
          quantity: Number(trQty),
          notes: trNotes,
        }),
      });
      showToast('Stock transferred between warehouses', 'success');
      setTrNotes('');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Transfer failed', 'error');
    }
  };

  const addWarehouse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!whName.trim()) return;
    try {
      await apiFetch('/api/warehouses', { method: 'POST', body: JSON.stringify({ name: whName, location: whLoc }) });
      setWhName('');
      setWhLoc('');
      showToast('Warehouse created', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to add warehouse', 'error');
    }
  };

  const filteredStock = products.filter((p) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      (p.product_code || '').toLowerCase().includes(q) ||
      (p.barcode || '').toLowerCase().includes(q)
    );
  });

  const filteredLowStock = lowStockItems.filter((p) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6">
      {/* Sub-navigation & Search */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => switchTab('stock')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'stock' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('inventory')} ({products.length})
          </button>
          <button
            onClick={() => switchTab('low_stock')}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium ${
              tab === 'low_stock' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            {t('lowStock')} ({lowStockItems.length})
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search product, code, SKU..."
            className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs w-56"
          />
        </div>
      </div>

      {/* Valuation Cards */}
      {summary && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Active Products / Units</div>
            <div className="text-xl font-bold font-mono-num text-[#0B1F4D] dark:text-[#F8FAFC] mt-1.5">
              {summary.total_products} · {summary.total_units} units
            </div>
          </div>
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Inventory Cost Value</div>
            <div className="text-xl font-bold font-mono-num text-[#2563EB] dark:text-[#06B6D4] mt-1.5">
              {formatMoney(summary.total_cost_value, 'ETB')}
            </div>
          </div>
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Inventory Retail Value</div>
            <div className="text-xl font-bold font-mono-num text-[#0B1F4D] dark:text-[#F8FAFC] mt-1.5">
              {formatMoney(summary.total_retail_value, 'ETB')}
            </div>
          </div>
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Low Stock / Out of Stock</div>
            <div className={`text-xl font-bold font-mono-num mt-1.5 ${summary.low_stock_count > 0 ? 'text-red-600 dark:text-red-400' : 'text-[#0B1F4D] dark:text-[#F8FAFC]'}`}>
              {summary.low_stock_count} / {summary.out_of_stock_count ?? 0}
            </div>
          </div>
        </div>
      )}

      {tab === 'low_stock' ? (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="px-5 py-3.5 border-b border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between">
            <h3 className="font-semibold text-sm text-red-600 dark:text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> Low Stock & Out-of-Stock Alerts
            </h3>
            <span className="text-xs font-mono-num text-slate-500">{filteredLowStock.length} item(s)</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Code / SKU</th>
                  <th className="text-left px-4 py-3 font-medium">Product Name</th>
                  <th className="text-left px-4 py-3 font-medium">Category</th>
                  <th className="text-right px-4 py-3 font-medium">Current Quantity</th>
                  <th className="text-right px-4 py-3 font-medium">Minimum Stock Level</th>
                  <th className="text-left px-4 py-3 font-medium">Alert Status</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredLowStock.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-slate-500">
                      All products are above minimum stock levels.
                    </td>
                  </tr>
                ) : (
                  filteredLowStock.map((p) => (
                    <tr key={p.id}>
                      <td className="px-4 py-3 font-mono-num">{p.product_code || p.sku}</td>
                      <td className="px-4 py-3 font-semibold">{p.name}</td>
                      <td className="px-4 py-3">{p.category_name || '-'}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-bold text-red-600">
                        {p.current_stock} {p.unit}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num">{p.min_stock} {p.unit}</td>
                      <td className="px-4 py-3">
                        <span className={p.current_stock <= 0 ? 'text-red-600 font-bold' : 'text-amber-600 font-semibold'}>
                          {p.current_stock <= 0 ? 'Out of Stock' : 'Low Stock Alert'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {hasPermission('inventory.manage') && (
                          <button
                            onClick={() => quickRestock(p.id)}
                            className="px-3 py-1 rounded-lg bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-medium"
                          >
                            Restock +
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <>
          {/* Operations Forms */}
          {hasPermission('inventory.manage') && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Stock Adjustment */}
              <form onSubmit={submitAdjustment} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 erp-card">
                <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
                  {adjType === 'IN' ? <PlusCircle className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" /> : <MinusCircle className="w-4 h-4 text-red-600" />}
                  {t('stockAdjustments')}
                </h3>
                <select
                  value={adjProd}
                  onChange={(e) => setAdjProd(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.current_stock} {p.unit})
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <select
                    value={adjType}
                    onChange={(e) => setAdjType(e.target.value as 'IN' | 'OUT')}
                    className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]"
                  >
                    <option value="IN">Stock In (+)</option>
                    <option value="OUT">Stock Out (-)</option>
                  </select>
                  <input
                    type="number"
                    min={0.01}
                    step="0.01"
                    required
                    value={adjQty}
                    onChange={(e) => setAdjQty(e.target.value)}
                    className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Reason / Notes"
                  value={adjNotes}
                  onChange={(e) => setAdjNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-xs"
                />
                <button type="submit" className="w-full py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors">
                  Apply Adjustment
                </button>
              </form>

              {/* Warehouse Transfer */}
              <form onSubmit={submitTransfer} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 erp-card">
                <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
                  <ArrowLeftRight className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
                  {t('stockTransfers')}
                </h3>
                <select
                  value={trProd}
                  onChange={(e) => setTrProd(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.current_stock} {p.unit})
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <select
                    value={trFrom}
                    onChange={(e) => setTrFrom(e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        From: {w.name}
                      </option>
                    ))}
                  </select>
                  <select
                    value={trTo}
                    onChange={(e) => setTrTo(e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        To: {w.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <input
                    type="number"
                    min={0.01}
                    step="0.01"
                    required
                    value={trQty}
                    onChange={(e) => setTrQty(e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                  />
                  <input
                    type="text"
                    placeholder="Transfer notes"
                    value={trNotes}
                    onChange={(e) => setTrNotes(e.target.value)}
                    className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                  />
                </div>
                <button type="submit" className="w-full py-2.5 rounded-xl bg-[#0B1F4D] hover:bg-[#132C66] dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors">
                  Transfer Stock
                </button>
              </form>

              {/* Warehouses */}
              <form onSubmit={addWarehouse} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 space-y-3 erp-card">
                <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
                  {t('warehouses')} ({warehouses.length})
                </h3>
                <div className="max-h-24 overflow-y-auto text-xs space-y-1">
                  {warehouses.map((w) => (
                    <div key={w.id} className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                      <span className="font-medium">{w.name}</span>
                      <span className="text-slate-500">{w.location}</span>
                    </div>
                  ))}
                </div>
                <input
                  type="text"
                  required
                  placeholder="New warehouse name"
                  value={whName}
                  onChange={(e) => setWhName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-xs"
                />
                <input
                  type="text"
                  placeholder="Location"
                  value={whLoc}
                  onChange={(e) => setWhLoc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-xs"
                />
                <button type="submit" className="w-full py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-semibold hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors">
                  Add Warehouse
                </button>
              </form>
            </div>
          )}

          {/* All Products Current Stock & Valuation Table */}
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              All Products Stock & Valuation
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">Product Code</th>
                    <th className="text-left px-4 py-3 font-medium">Product Name</th>
                    <th className="text-left px-4 py-3 font-medium">Warehouse</th>
                    <th className="text-right px-4 py-3 font-medium">Current Stock</th>
                    <th className="text-right px-4 py-3 font-medium">Min Stock</th>
                    <th className="text-right px-4 py-3 font-medium">Stock Valuation</th>
                    <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredStock.map((p) => (
                    <tr key={p.id}>
                      <td className="px-4 py-2.5 font-mono-num">{p.product_code || p.sku}</td>
                      <td className="px-4 py-2.5 font-semibold">{p.name}</td>
                      <td className="px-4 py-2.5">{p.warehouse_name || 'Main Store'}</td>
                      <td className={`px-4 py-2.5 text-right font-mono-num font-semibold ${p.current_stock <= p.min_stock ? 'text-red-600' : ''}`}>
                        {p.current_stock} {p.unit}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono-num">{p.min_stock} {p.unit}</td>
                      <td className="px-4 py-2.5 text-right font-mono-num">{formatMoney(p.current_stock * p.purchase_price, 'ETB')}</td>
                      <td className="px-4 py-2.5">
                        <span className={p.current_stock <= 0 ? 'text-red-600 font-semibold' : p.current_stock <= p.min_stock ? 'text-amber-600 font-medium' : 'text-emerald-600 font-medium'}>
                          {p.current_stock <= 0 ? 'Out of Stock' : p.current_stock <= p.min_stock ? 'Low Stock' : 'In Stock'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Expiry Alerts */}
          {expiring.length > 0 && (
            <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-5 erp-card">
              <h3 className="font-semibold text-sm mb-3 text-amber-700 dark:text-amber-400">Product Expiry Tracking (Within 60 Days / Expired)</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500">
                      <th className="text-left pb-2 font-medium">Product</th>
                      <th className="text-left pb-2 font-medium">{t('sku')}</th>
                      <th className="text-right pb-2 font-medium">{t('currentStock')}</th>
                      <th className="text-right pb-2 font-medium">{t('expiryDate')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {expiring.map((e) => (
                      <tr key={e.id}>
                        <td className="py-2 font-medium">{e.name}</td>
                        <td className="py-2 font-mono-num">{e.sku}</td>
                        <td className="py-2 text-right font-mono-num">{e.current_stock} {e.unit}</td>
                        <td className="py-2 text-right font-mono-num text-red-600">{e.expiry_date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Stock Movement History */}
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] dark:border-slate-800 font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">
              {t('stockMovements')}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                    <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                    <th className="text-left px-4 py-3 font-medium">Product</th>
                    <th className="text-left px-4 py-3 font-medium">Warehouse</th>
                    <th className="text-left px-4 py-3 font-medium">Movement</th>
                    <th className="text-right px-4 py-3 font-medium">{t('quantity')}</th>
                    <th className="text-left px-4 py-3 font-medium">Reference</th>
                    <th className="text-left px-4 py-3 font-medium">User</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {movements.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-10 text-center text-slate-500">
                        {t('noRecords')}
                      </td>
                    </tr>
                  ) : (
                    movements.map((m) => (
                      <tr key={m.id}>
                        <td className="px-4 py-2.5 font-mono-num text-slate-500">{m.created_at}</td>
                        <td className="px-4 py-2.5 font-medium">{m.product_name} ({m.sku})</td>
                        <td className="px-4 py-2.5">{m.warehouse_name || '-'}</td>
                        <td className="px-4 py-2.5 font-mono-num">{m.movement_type}</td>
                        <td className="px-4 py-2.5 text-right font-mono-num font-semibold">
                          {m.quantity} {m.unit}
                        </td>
                        <td className="px-4 py-2.5 font-mono-num text-slate-500">{m.reference_id || m.notes}</td>
                        <td className="px-4 py-2.5 text-slate-500">{m.created_by}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
