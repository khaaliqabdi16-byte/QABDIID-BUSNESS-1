import React, { useEffect, useState, useCallback } from 'react';
import { Search, Eye, RotateCcw, CreditCard, Edit2, Trash2, Printer, Download, X, History } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney, generateSaleReturnPdf } from '../utils/export.ts';
import { Customer, CustomerSalesSummary, Sale, SaleItem } from '../types/erp.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';

interface SaleReturnRecord {
  id: number;
  return_number: string;
  invoice_number: string;
  customer_name: string;
  return_date: string;
  total_refund: number;
  refund_method: string;
  reason?: string;
  status?: string;
  notes: string;
  items_summary?: string;
  total_quantity?: number;
  created_by: string;
}

interface SaleReturnDetail {
  saleReturn: SaleReturnRecord;
  items: Array<{
    id: number;
    product_name: string;
    quantity: number;
    unit_price: number;
    vat_amount: number;
    subtotal: number;
  }>;
}

type SalesTab = 'sales' | 'returns' | 'customer_sales';

export function SalesPage() {
  const { t, settings, activeSubTab, setActiveSubTab, hasPermission, showToast, refreshNotifications } = useApp();
  const [tab, setTab] = useState<SalesTab>(() =>
    activeSubTab === 'returns' || activeSubTab === 'customer_sales' ? activeSubTab : 'sales'
  );
  const [sales, setSales] = useState<Sale[]>([]);
  const [returns, setReturns] = useState<SaleReturnRecord[]>([]);
  const [customerSummaries, setCustomerSummaries] = useState<CustomerSalesSummary[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [receiptData, setReceiptData] = useState<{ sale: Sale; items: SaleItem[] } | null>(null);
  const [returnModal, setReturnModal] = useState<{ sale: Sale; items: SaleItem[] } | null>(null);
  const [returnQtys, setReturnQtys] = useState<Record<number, number>>({});
  const [refundMethod, setRefundMethod] = useState('Cash');
  const [returnReason, setReturnReason] = useState('');
  const [returnStatus, setReturnStatus] = useState('Refunded');
  const [returnNotes, setReturnNotes] = useState('');
  const [returnReceiptModal, setReturnReceiptModal] = useState<SaleReturnDetail | null>(null);

  const [editModal, setEditModal] = useState<Sale | null>(null);
  const [editDate, setEditDate] = useState('');
  const [editCustomerId, setEditCustomerId] = useState<number>(1);
  const [editMethod, setEditMethod] = useState('Cash');
  const [editNotes, setEditNotes] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<Sale | null>(null);

  const [payModal, setPayModal] = useState<Sale | null>(null);
  const [payAmt, setPayAmt] = useState('');
  const [payMethod, setPayMethod] = useState('Cash');

  const [historyModal, setHistoryModal] = useState<{
    customerName: string;
    sales: Array<Record<string, unknown>>;
    payments: Array<Record<string, unknown>>;
  } | null>(null);

  useEffect(() => {
    if (activeSubTab === 'sales' || activeSubTab === 'returns' || activeSubTab === 'customer_sales') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const handleTabChange = (next: SalesTab) => {
    setTab(next);
    setActiveSubTab(next);
  };

  const loadData = useCallback(async () => {
    try {
      const qs = new URLSearchParams();
      if (search.trim()) qs.set('q', search.trim());
      if (statusFilter) qs.set('status', statusFilter);
      const [sRes, rRes, csRes, custRes] = await Promise.all([
        apiFetch<{ sales: Sale[] }>(`/api/sales?${qs.toString()}`),
        apiFetch<{ returns: SaleReturnRecord[] }>('/api/sales/returns'),
        apiFetch<{ summaries: CustomerSalesSummary[] }>('/api/sales/customer-summary'),
        apiFetch<{ customers: Customer[] }>('/api/customers'),
      ]);
      setSales(sRes.sales);
      setReturns(rRes.returns);
      setCustomerSummaries(csRes.summaries);
      setCustomers(custRes.customers);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load sales', 'error');
    }
  }, [search, statusFilter, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openReceipt = async (saleId: number) => {
    try {
      const detail = await apiFetch<{ sale: Sale; items: SaleItem[] }>(`/api/sales/${saleId}`);
      setReceiptData(detail);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load invoice', 'error');
    }
  };

  const openEditModal = (sale: Sale) => {
    setEditModal(sale);
    setEditDate(sale.sale_date);
    setEditCustomerId(sale.customer_id || 1);
    setEditMethod(sale.payment_method || 'Cash');
    setEditNotes(sale.notes || '');
  };

  const submitEditSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;
    try {
      await apiFetch(`/api/sales/${editModal.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          sale_date: editDate,
          customer_id: editCustomerId,
          payment_method: editMethod,
          notes: editNotes,
        }),
      });
      showToast(`Updated ${editModal.invoice_number}`, 'success');
      setEditModal(null);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to update sale', 'error');
    }
  };

  const confirmDeleteSale = async () => {
    if (!deleteTarget) return;
    try {
      await apiFetch(`/api/sales/${deleteTarget.id}`, { method: 'DELETE' });
      showToast(`Deleted and reversed ${deleteTarget.invoice_number}`, 'success');
      setDeleteTarget(null);
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete sale', 'error');
    }
  };

  const openReturnModal = async (saleId: number) => {
    try {
      const detail = await apiFetch<{ sale: Sale; items: SaleItem[] }>(`/api/sales/${saleId}`);
      const initQtys: Record<number, number> = {};
      for (const i of detail.items) initQtys[i.id] = 0;
      setReturnQtys(initQtys);
      setReturnReason('');
      setReturnStatus('Refunded');
      setReturnNotes('');
      setReturnModal(detail);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to open return dialog', 'error');
    }
  };

  const submitReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnModal) return;
    const items = Object.entries(returnQtys)
      .filter(([, qty]) => qty > 0)
      .map(([sale_item_id, quantity]) => ({ sale_item_id: Number(sale_item_id), quantity }));
    if (items.length === 0) {
      showToast('Specify at least one item quantity to return', 'error');
      return;
    }
    try {
      const res = await apiFetch<{ return_number: string }>('/api/sales/returns', {
        method: 'POST',
        body: JSON.stringify({
          sale_id: returnModal.sale.id,
          items,
          refund_method: refundMethod,
          reason: returnReason,
          status: returnStatus,
          notes: returnNotes || returnReason,
        }),
      });
      showToast(`Created return ${res.return_number}`, 'success');
      setReturnModal(null);
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Return failed', 'error');
    }
  };

  const openReturnReceipt = async (returnId: number) => {
    try {
      const detail = await apiFetch<SaleReturnDetail>(`/api/sales/returns/${returnId}`);
      setReturnReceiptModal(detail);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to load return receipt', 'error');
    }
  };

  const submitBalancePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModal) return;
    try {
      await apiFetch(`/api/customers/${payModal.customer_id}/pay`, {
        method: 'POST',
        body: JSON.stringify({
          sale_id: payModal.id,
          amount: Number(payAmt),
          currency: payModal.currency,
          payment_method: payMethod,
          notes: `Payment on ${payModal.invoice_number}`,
        }),
      });
      showToast('Payment recorded', 'success');
      setPayModal(null);
      await Promise.all([loadData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Payment failed', 'error');
    }
  };

  const viewCustomerHistory = async (customerId: number, customerName: string) => {
    try {
      const res = await apiFetch<{ sales: Array<Record<string, unknown>>; payments: Array<Record<string, unknown>> }>(
        `/api/customers/${customerId}/statement`
      );
      setHistoryModal({ customerName, sales: res.sales, payments: res.payments });
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to load customer sales history', 'error');
    }
  };

  return (
    <div className="space-y-5">
      {/* Sub-navigation & Filters */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => handleTabChange('sales')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap ${
              tab === 'sales' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('salesMain')} ({sales.length})
          </button>
          <button
            onClick={() => handleTabChange('returns')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap ${
              tab === 'returns' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('salesReturns')} ({returns.length})
          </button>
          <button
            onClick={() => handleTabChange('customer_sales')}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap ${
              tab === 'customer_sales' ? 'bg-[#2563EB] text-white shadow-xs' : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {t('customerSales')} ({customerSummaries.length})
          </button>
        </div>

        {tab === 'sales' && (
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="SAL-000001 or customer..."
                className="pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs w-56"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
            >
              <option value="">All Statuses</option>
              <option value="Paid">{t('paid')}</option>
              <option value="Partially Paid">{t('partiallyPaid')}</option>
              <option value="Credit">{t('credit')}</option>
              <option value="Partially Returned">{t('partiallyReturned')}</option>
              <option value="Returned">{t('returned')}</option>
              <option value="Held">{t('held')}</option>
            </select>
          </div>
        )}
      </div>

      {tab === 'sales' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Invoice</th>
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('customer')}</th>
                  <th className="text-left px-4 py-3 font-medium">Products ({t('quantity')})</th>
                  <th className="text-left px-4 py-3 font-medium">{t('paymentMethod')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('discount')} / {t('vat')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('total')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('amountPaid')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {sales.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  sales.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3 font-mono-num font-semibold">{s.invoice_number}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{s.sale_date}</td>
                      <td className="px-4 py-3">{s.customer_name || 'Walk-In'}</td>
                      <td className="px-4 py-3 max-w-[200px]">
                        <div className="truncate text-slate-700 dark:text-slate-200" title={s.items_summary || ''}>
                          {s.items_summary || '-'}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono-num">Qty: {s.total_quantity ?? 0} · {s.created_by}</div>
                      </td>
                      <td className="px-4 py-3">{s.payment_method}</td>
                      <td className="px-4 py-3 text-right font-mono-num text-[11px] text-slate-500">
                        -{formatMoney(s.discount_amount, s.currency)} / +{formatMoney(s.vat_amount, s.currency)}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">
                        {formatMoney(s.grand_total, s.currency)}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num">
                        {formatMoney(s.paid_amount, s.currency)}
                      </td>
                      <td className="px-4 py-3 text-right font-mono-num text-amber-600 dark:text-amber-400">
                        {formatMoney(s.balance_amount, s.currency)}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`font-medium ${
                            s.status === 'Paid'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : s.status === 'Credit' || s.status === 'Returned'
                              ? 'text-red-600 dark:text-red-400'
                              : 'text-amber-700 dark:text-amber-400'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => openReceipt(s.id)}
                            className="p-1.5 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                            title="View Receipt"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {s.balance_amount > 0.01 && s.status !== 'Held' && s.status !== 'Cancelled' && (
                            <button
                              onClick={() => {
                                setPayModal(s);
                                setPayAmt(String(s.balance_amount));
                              }}
                              className="p-1.5 rounded-lg border border-[#E2E8F0] dark:border-slate-700 text-[#2563EB] dark:text-[#06B6D4] hover:bg-[#2563EB]/10"
                              title={t('recordPayment')}
                            >
                              <CreditCard className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('sales.return') && s.status !== 'Held' && s.status !== 'Cancelled' && s.status !== 'Returned' && (
                            <button
                              onClick={() => openReturnModal(s.id)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/30"
                              title={t('salesReturn')}
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('sales.manage') && (
                            <button
                              onClick={() => openEditModal(s)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                              title={t('edit')}
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {hasPermission('sales.delete') && (
                            <button
                              onClick={() => setDeleteTarget(s)}
                              className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30"
                              title={t('delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'returns' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Return #</th>
                  <th className="text-left px-4 py-3 font-medium">Invoice #</th>
                  <th className="text-left px-4 py-3 font-medium">{t('date')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('customer')}</th>
                  <th className="text-left px-4 py-3 font-medium">Returned Items</th>
                  <th className="text-left px-4 py-3 font-medium">Reason</th>
                  <th className="text-left px-4 py-3 font-medium">Refund Method</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">Total Refund</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {returns.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="py-10 text-center text-slate-500">
                      {t('noRecords')}
                    </td>
                  </tr>
                ) : (
                  returns.map((r) => (
                    <tr key={r.id}>
                      <td className="px-4 py-3 font-mono-num font-semibold">{r.return_number}</td>
                      <td className="px-4 py-3 font-mono-num">{r.invoice_number}</td>
                      <td className="px-4 py-3 font-mono-num text-slate-500">{r.return_date}</td>
                      <td className="px-4 py-3">{r.customer_name || 'Walk-In'}</td>
                      <td className="px-4 py-3 max-w-[180px] truncate" title={r.items_summary || ''}>
                        {r.items_summary || '-'} ({r.total_quantity ?? 0})
                      </td>
                      <td className="px-4 py-3 text-slate-500">{r.reason || r.notes || '-'}</td>
                      <td className="px-4 py-3">{r.refund_method}</td>
                      <td className="px-4 py-3 font-medium text-emerald-700 dark:text-emerald-400">{r.status || 'Refunded'}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold text-red-600">
                        {formatMoney(r.total_refund, 'ETB')}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => openReturnReceipt(r.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                          title={t('printReturnReceipt')}
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'customer_sales' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Code</th>
                  <th className="text-left px-4 py-3 font-medium">{t('customer')}</th>
                  <th className="text-left px-4 py-3 font-medium">{t('phone')}</th>
                  <th className="text-right px-4 py-3 font-medium">Invoices</th>
                  <th className="text-right px-4 py-3 font-medium">{t('totalSales')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('amountPaid')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('remainingBalance')} (ETB)</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {customerSummaries.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-500">{t('noRecords')}</td>
                  </tr>
                ) : (
                  customerSummaries.map((cs) => (
                    <tr key={cs.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="px-4 py-3 font-mono-num text-slate-500">{cs.customer_code || `#${cs.id}`}</td>
                      <td className="px-4 py-3 font-semibold">{cs.full_name}</td>
                      <td className="px-4 py-3 text-slate-500">{cs.phone || '-'}</td>
                      <td className="px-4 py-3 text-right font-mono-num">{cs.invoice_count}</td>
                      <td className="px-4 py-3 text-right font-mono-num font-semibold">{formatMoney(cs.total_sales_etb, 'ETB')}</td>
                      <td className="px-4 py-3 text-right font-mono-num text-emerald-600">{formatMoney(cs.total_paid_etb, 'ETB')}</td>
                      <td className={`px-4 py-3 text-right font-mono-num font-semibold ${cs.outstanding_balance > 0 ? 'text-amber-600' : ''}`}>
                        {formatMoney(cs.outstanding_balance, 'ETB')}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => viewCustomerHistory(cs.id, cs.full_name)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <History className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" />
                          History
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {receiptData && (
        <ReceiptModal
          sale={receiptData.sale}
          items={receiptData.items}
          settings={settings}
          onClose={() => setReceiptData(null)}
        />
      )}

      {/* Edit Sale Modal */}
      {editModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form onSubmit={submitEditSale} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-md p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{t('edit')} · {editModal.invoice_number}</h3>
              <button type="button" onClick={() => setEditModal(null)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('date')}</label>
              <input
                type="date"
                value={editDate}
                onChange={(e) => setEditDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
              />
            </div>
            <div>
              <label className="block font-medium mb-1">{t('customer')}</label>
              <select
                value={editCustomerId}
                onChange={(e) => setEditCustomerId(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>{c.full_name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1">{t('paymentMethod')}</label>
              <select
                value={editMethod}
                onChange={(e) => setEditMethod(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                <option value="Cash">{t('cash')}</option>
                <option value="Card">{t('cardPayment')}</option>
                <option value="Bank Transfer">{t('bankTransfer')}</option>
                <option value="Mobile Money">{t('mobileMoney')}</option>
                <option value="Credit">{t('creditDebt')}</option>
                <option value="Split">{t('splitPayment')}</option>
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1">Notes</label>
              <input
                type="text"
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setEditModal(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">{t('cancel')}</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold">{t('save')}</button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Sale Confirmation */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-sm p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm text-red-600">{t('delete')} · {deleteTarget.invoice_number}</h3>
              <button onClick={() => setDeleteTarget(null)}><X className="w-4 h-4" /></button>
            </div>
            <p className="text-slate-600 dark:text-slate-300">
              {t('confirmDelete')} Stock quantities, customer balance, and accounting entries will be reversed.
            </p>
            <div className="flex justify-end gap-2">
              <button onClick={() => setDeleteTarget(null)} className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700">{t('cancel')}</button>
              <button onClick={confirmDeleteSale} className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-semibold">{t('delete')}</button>
            </div>
          </div>
        </div>
      )}

      {/* Sales Return Modal */}
      {returnModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={submitReturn}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">
                {t('salesReturn')} · {returnModal.sale.invoice_number}
              </h3>
              <button type="button" onClick={() => setReturnModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {returnModal.items.map((item) => {
                const maxReturn = item.quantity - item.returned_qty;
                return (
                  <div key={item.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold">{item.product_name}</div>
                      <div className="text-slate-500 font-mono-num">
                        Sold: {item.quantity} · Returned: {item.returned_qty} · Available: {maxReturn}
                      </div>
                    </div>
                    <input
                      type="number"
                      min={0}
                      max={maxReturn}
                      value={returnQtys[item.id] || 0}
                      disabled={maxReturn <= 0}
                      onChange={(e) =>
                        setReturnQtys((prev) => ({
                          ...prev,
                          [item.id]: Math.min(maxReturn, Math.max(0, Number(e.target.value) || 0)),
                        }))
                      }
                      className="w-20 text-right px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                    />
                  </div>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block font-medium mb-1">Refund Method</label>
                <select
                  value={refundMethod}
                  onChange={(e) => setRefundMethod(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Cash">{t('cash')}</option>
                  <option value="Card">{t('cardPayment')}</option>
                  <option value="Bank Transfer">{t('bankTransfer')}</option>
                  <option value="Mobile Money">{t('mobileMoney')}</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">Return Status</label>
                <select
                  value={returnStatus}
                  onChange={(e) => setReturnStatus(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Refunded">Refunded</option>
                  <option value="Credited">Credited</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1">Return Reason</label>
                <input
                  type="text"
                  required
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  placeholder="Damaged / Wrong item..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
                />
              </div>
            </div>
            <div className="text-xs">
              <label className="block font-medium mb-1">Notes</label>
              <input
                type="text"
                value={returnNotes}
                onChange={(e) => setReturnNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setReturnModal(null)}
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs"
              >
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Return Receipt Printable Modal */}
      {returnReceiptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800 no-print">
              <h3 className="font-semibold text-sm">{t('printReturnReceipt')}</h3>
              <button onClick={() => setReturnReceiptModal(null)}><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-2 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-4">
              <div className="text-center font-bold text-sm">{settings?.business_name || 'QABDIID BUSNESS 1'}</div>
              <div className="text-center text-[11px] text-slate-500">SALES RETURN RECEIPT</div>
              <div className="grid grid-cols-2 gap-1 pt-2 border-t border-slate-200 dark:border-slate-800 font-mono-num">
                <span>Return #: {returnReceiptModal.saleReturn.return_number}</span>
                <span className="text-right">Invoice #: {returnReceiptModal.saleReturn.invoice_number}</span>
                <span>Date: {returnReceiptModal.saleReturn.return_date}</span>
                <span className="text-right">Status: {returnReceiptModal.saleReturn.status || 'Refunded'}</span>
              </div>
              <div>Customer: <span className="font-semibold">{returnReceiptModal.saleReturn.customer_name || 'Walk-In'}</span></div>
              {returnReceiptModal.saleReturn.reason && (
                <div>Reason: <span className="text-slate-600 dark:text-slate-300">{returnReceiptModal.saleReturn.reason}</span></div>
              )}
              <div className="divide-y divide-slate-100 dark:divide-slate-800 border-t border-b border-slate-200 dark:border-slate-800 py-1 my-2">
                {returnReceiptModal.items.map((it) => (
                  <div key={it.id} className="py-1 flex justify-between">
                    <span>{it.product_name} x{it.quantity}</span>
                    <span className="font-mono-num">{formatMoney(it.subtotal, 'ETB')}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold text-sm">
                <span>Total Refund</span>
                <span className="font-mono-num text-red-600">{formatMoney(returnReceiptModal.saleReturn.total_refund, 'ETB')}</span>
              </div>
            </div>
            <div className="flex justify-end gap-2 no-print">
              <button
                onClick={() =>
                  generateSaleReturnPdf(returnReceiptModal.saleReturn, returnReceiptModal.items, settings)
                }
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 font-medium"
              >
                <Download className="w-3.5 h-3.5" /> {t('downloadPdf')}
              </button>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] text-white font-semibold"
              >
                <Printer className="w-3.5 h-3.5" /> {t('printReturnReceipt')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Sales History Modal */}
      {historyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-2xl p-5 space-y-4 max-h-[85vh] overflow-y-auto text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-semibold text-sm">{t('customerSales')} · {historyModal.customerName}</h3>
              <button onClick={() => setHistoryModal(null)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <div className="font-semibold mb-2">Invoices ({historyModal.sales.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">Invoice #</th>
                    <th className="text-left p-2">{t('date')}</th>
                    <th className="text-right p-2">{t('total')}</th>
                    <th className="text-right p-2">{t('amountPaid')}</th>
                    <th className="text-right p-2">{t('remainingBalance')}</th>
                    <th className="text-left p-2">{t('status')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {historyModal.sales.map((r, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(r.invoice_number)}</td>
                      <td className="p-2 font-mono-num">{String(r.sale_date)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.grand_total), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.paid_amount), String(r.currency))}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(r.balance_amount), String(r.currency))}</td>
                      <td className="p-2">{String(r.status)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div>
              <div className="font-semibold mb-2">Payment History ({historyModal.payments.length})</div>
              <table className="w-full border border-slate-200 dark:border-slate-800">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500">
                    <th className="text-left p-2">{t('date')}</th>
                    <th className="text-left p-2">Method</th>
                    <th className="text-right p-2">Amount</th>
                    <th className="text-left p-2">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {historyModal.payments.map((p, i) => (
                    <tr key={i}>
                      <td className="p-2 font-mono-num">{String(p.created_at)}</td>
                      <td className="p-2">{String(p.payment_method)}</td>
                      <td className="p-2 text-right font-mono-num">{formatMoney(Number(p.amount), String(p.currency))}</td>
                      <td className="p-2 text-slate-500">{String(p.notes || '-')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Record Balance Payment Modal */}
      {payModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <form
            onSubmit={submitBalancePayment}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-sm p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">
                {t('recordPayment')} · {payModal.invoice_number}
              </h3>
              <button type="button" onClick={() => setPayModal(null)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-slate-500">
              Outstanding: <span className="font-mono-num font-semibold">{formatMoney(payModal.balance_amount, payModal.currency)}</span>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">{t('amountPaid')} ({payModal.currency})</label>
              <input
                type="number"
                step="0.01"
                min={0.01}
                max={payModal.balance_amount}
                required
                value={payAmt}
                onChange={(e) => setPayAmt(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent text-sm font-mono-num"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">{t('paymentMethod')}</label>
              <select
                value={payMethod}
                onChange={(e) => setPayMethod(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="Cash">{t('cash')}</option>
                <option value="Card">{t('cardPayment')}</option>
                <option value="Bank Transfer">{t('bankTransfer')}</option>
                <option value="Mobile Money">{t('mobileMoney')}</option>
              </select>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPayModal(null)}
                className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs"
              >
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
