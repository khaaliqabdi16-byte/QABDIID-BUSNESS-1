import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  User as UserIcon,
  Eye,
  EyeOff,
  Copy,
  Check,
  ShieldCheck,
  KeyRound,
  Monitor,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { compressImageFile } from '../utils/image.ts';

interface SessionRow {
  tokenPrefix: string;
  isCurrent: boolean;
  ip_info: string;
  user_agent: string;
  created_at: string;
  expires_at: string;
}

type ProfileTab = 'personal' | 'password' | 'sessions' | '2fa';

export function ProfilePage() {
  const { user, refreshUser, showToast, t, settings } = useApp();
  const [activeTab, setActiveTab] = useState<ProfileTab>('personal');

  // Personal information state
  const [photoUrl, setPhotoUrl] = useState(user?.photo_url || '');
  const [photoFileName, setPhotoFileName] = useState('');
  const [firstName, setFirstName] = useState(user?.first_name || '');
  const [lastName, setLastName] = useState(user?.last_name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [gender, setGender] = useState(user?.gender || '');
  const [dateOfBirth, setDateOfBirth] = useState(user?.date_of_birth || '');
  const [country, setCountry] = useState(user?.country || '');
  const [address, setAddress] = useState(user?.address || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Change password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  // Sessions & 2FA state
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [twoFactorSecret, setTwoFactorSecret] = useState('');
  const [toggling2fa, setToggling2fa] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  useEffect(() => {
    if (user) {
      setPhotoUrl(user.photo_url || '');
      setFirstName(user.first_name || '');
      setLastName(user.last_name || '');
      setEmail(user.email || '');
      setPhone(user.phone || '');
      setGender(user.gender || '');
      setDateOfBirth(user.date_of_birth || '');
      setCountry(user.country || '');
      setAddress(user.address || '');
    }
  }, [user]);

  const loadSessions = useCallback(async () => {
    setLoadingSessions(true);
    try {
      const res = await apiFetch<{ sessions: SessionRow[] }>('/api/sessions');
      setSessions(res.sessions);
    } catch {
      // ignore
    } finally {
      setLoadingSessions(false);
    }
  }, []);

  const load2faStatus = useCallback(async () => {
    try {
      const res = await apiFetch<{ two_factor_enabled: number; secret: string }>('/api/profile/2fa');
      setTwoFactorSecret(res.secret || '');
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    loadSessions();
    load2faStatus();
  }, [loadSessions, load2faStatus]);

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImageFile(file, 360, 0.85);
      setPhotoUrl(compressed);
      setPhotoFileName(file.name);
      showToast('Photo ready — click Save to update your profile', 'success');
    } catch {
      showToast('Unable to read selected image file', 'error');
    }
    e.target.value = '';
  };

  const updateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await apiFetch('/api/profile', {
        method: 'PUT',
        body: JSON.stringify({
          first_name: firstName,
          last_name: lastName,
          username: user?.username,
          email,
          phone,
          photo_url: photoUrl,
          gender,
          date_of_birth: dateOfBirth,
          country,
          address,
        }),
      });
      await refreshUser();
      showToast('Profile saved successfully', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to update profile', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      showToast('New password and confirmation do not match', 'error');
      return;
    }
    setSavingPassword(true);
    try {
      await apiFetch('/api/profile/password', {
        method: 'PUT',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      showToast('Password changed successfully', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to change password', 'error');
    } finally {
      setSavingPassword(false);
    }
  };

  const toggle2FA = async () => {
    setToggling2fa(true);
    try {
      const res = await apiFetch<{ two_factor_enabled: number; secret: string }>('/api/profile/2fa', {
        method: 'PUT',
        body: JSON.stringify({ enabled: !user?.two_factor_enabled }),
      });
      setTwoFactorSecret(res.secret || '');
      await refreshUser();
      showToast(res.two_factor_enabled ? 'Two-Factor Authentication enabled' : 'Two-Factor Authentication disabled', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to toggle 2FA', 'error');
    } finally {
      setToggling2fa(false);
    }
  };

  const revokeSession = async (prefix: string) => {
    try {
      await apiFetch(`/api/sessions/${prefix}`, { method: 'DELETE' });
      await loadSessions();
      showToast('Session revoked', 'success');
    } catch {
      showToast('Unable to revoke session', 'error');
    }
  };

  const copy2faSecret = async () => {
    if (!twoFactorSecret) return;
    try {
      await navigator.clipboard.writeText(twoFactorSecret);
      setCopiedKey(true);
      showToast('2FA key copied to clipboard', 'success');
      setTimeout(() => setCopiedKey(false), 2000);
    } catch {
      showToast(twoFactorSecret, 'success');
    }
  };

  const tabs: Array<{ key: ProfileTab; label: string }> = [
    { key: 'personal', label: t('personalInfo') },
    { key: 'password', label: t('changePassword') },
    { key: 'sessions', label: t('sessions') },
    { key: '2fa', label: t('twoFactorAuth') },
  ];

  const otherSessionsCount = sessions.filter((s) => !s.isCurrent).length;

  return (
    <div className="max-w-5xl space-y-5">
      <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
        {t('accountSecurity')}
      </p>

      {/* Main Profile Card matching clean tabbed layout */}
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl erp-card overflow-hidden">
        {/* Underline Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-[#E2E8F0] dark:border-slate-800 flex items-center gap-6 overflow-x-auto">
          {tabs.map((item) => {
            const active = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveTab(item.key)}
                className={`pb-3 text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 border-b-2 transition-colors ${
                  active
                    ? 'border-[#2563EB] text-[#2563EB] dark:border-[#06B6D4] dark:text-[#06B6D4]'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-[#0B1F4D] dark:hover:text-[#F8FAFC]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Tab 1: Personal Information */}
        {activeTab === 'personal' && (
          <form onSubmit={updateProfile} className="p-6 space-y-5 text-xs">
            {/* Profile Photo Row */}
            <div className="flex flex-wrap items-center gap-4">
              <div className="w-20 h-20 rounded-full bg-[#2563EB]/10 dark:bg-[#06B6D4]/15 border border-[#E2E8F0] dark:border-slate-700 flex items-center justify-center overflow-hidden shrink-0">
                {photoUrl ? (
                  <img
                    src={photoUrl}
                    alt={`${firstName} ${lastName}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <UserIcon className="w-9 h-9 text-[#2563EB] dark:text-[#06B6D4]" />
                )}
              </div>

              <div className="space-y-1.5 min-w-[240px]">
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                  {t('profilePhoto')}
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    ref={photoInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoSelect}
                    className="hidden"
                  />
                  <div className="inline-flex items-center rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] overflow-hidden">
                    <button
                      type="button"
                      onClick={() => photoInputRef.current?.click()}
                      className="px-3.5 py-2 text-xs font-medium text-[#0B1F4D] dark:text-[#F8FAFC] bg-white dark:bg-[#161F33] border-r border-[#E2E8F0] dark:border-slate-700 hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
                    >
                      {t('chooseFile')}
                    </button>
                    <span className="px-3 py-2 text-xs text-slate-500 dark:text-slate-400 truncate max-w-[200px]">
                      {photoFileName || (photoUrl ? 'Profile photo uploaded' : t('noFileChosen'))}
                    </span>
                  </div>
                  {photoUrl && (
                    <button
                      type="button"
                      onClick={() => {
                        setPhotoUrl('');
                        setPhotoFileName('');
                      }}
                      className="text-xs font-medium text-red-600 dark:text-red-400 hover:underline px-2 py-1"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Row 1: First name | Last name */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('firstName')}
                </label>
                <input
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('lastName')}
                </label>
                <input
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
            </div>

            {/* Row 2: Email | Phone */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('email')}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('phone')}
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+251 9..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm font-mono-num text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
            </div>

            {/* Row 3: Gender | Date of birth | Country */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('gender')}
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
                >
                  <option value="">{t('selectGender')}</option>
                  <option value="Male">{t('male')}</option>
                  <option value="Female">{t('female')}</option>
                  <option value="Other">{t('other')}</option>
                </select>
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('dateOfBirth')}
                </label>
                <input
                  type="date"
                  value={dateOfBirth}
                  onChange={(e) => setDateOfBirth(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm font-mono-num text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('country')}
                </label>
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="Ethiopia / Somalia"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
                />
              </div>
            </div>

            {/* Row 4: Address */}
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                {t('address')}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Street, District, City"
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm text-[#111827] dark:text-[#F8FAFC]"
              />
            </div>

            {/* Save Button */}
            <div className="pt-1 flex items-center justify-between gap-4">
              <button
                type="submit"
                disabled={savingProfile}
                className="px-5 py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-sm font-semibold shadow-sm transition-colors disabled:opacity-60"
              >
                {savingProfile ? t('loading') : t('save')}
              </button>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono-num">
                @{user?.username} · {user?.role}
              </span>
            </div>
          </form>
        )}

        {/* Tab 2: Change Password */}
        {activeTab === 'password' && (
          <form onSubmit={changePassword} className="p-6 max-w-lg space-y-4 text-xs">
            <div className="flex items-center gap-2 text-[#0B1F4D] dark:text-[#F8FAFC]">
              <KeyRound className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
              <h2 className="font-display font-bold text-sm">{t('changePassword')}</h2>
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Current password
              </label>
              <div className="relative">
                <input
                  type={showCurrentPw ? 'text' : 'password'}
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPw((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#2563EB]"
                  aria-label="Toggle password visibility"
                >
                  {showCurrentPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                New password
              </label>
              <div className="relative">
                <input
                  type={showNewPw ? 'text' : 'password'}
                  required
                  minLength={settings?.min_password_length || 6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPw((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#2563EB]"
                  aria-label="Toggle password visibility"
                >
                  {showNewPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Minimum {settings?.min_password_length || 6} characters.
              </p>
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Confirm new password
              </label>
              <input
                type={showNewPw ? 'text' : 'password'}
                required
                minLength={settings?.min_password_length || 6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm"
              />
            </div>

            <div className="pt-1">
              <button
                type="submit"
                disabled={savingPassword}
                className="px-5 py-2.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-sm font-semibold shadow-sm transition-colors disabled:opacity-60"
              >
                {savingPassword ? t('loading') : 'Update Password'}
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: Sessions */}
        {activeTab === 'sessions' && (
          <div className="p-6 space-y-4 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-[#0B1F4D] dark:text-[#F8FAFC]">
                <Monitor className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
                <h2 className="font-display font-bold text-sm">
                  Active Sessions ({sessions.length})
                </h2>
              </div>
              {otherSessionsCount > 0 && (
                <button
                  type="button"
                  onClick={() => revokeSession('others')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-red-200 dark:border-red-900/60 text-red-600 dark:text-red-400 font-semibold hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Sign out other sessions ({otherSessionsCount})
                </button>
              )}
            </div>

            {loadingSessions ? (
              <div className="py-8 text-center text-slate-500">{t('loading')}</div>
            ) : sessions.length === 0 ? (
              <div className="py-8 text-center text-slate-500">{t('noRecords')}</div>
            ) : (
              <div className="divide-y divide-[#E2E8F0] dark:divide-slate-800 border border-[#E2E8F0] dark:border-slate-800 rounded-xl overflow-hidden">
                {sessions.map((s) => (
                  <div
                    key={s.tokenPrefix}
                    className="p-4 flex flex-wrap items-center justify-between gap-4 bg-[#F8FAFC]/50 dark:bg-[#111827]/40"
                  >
                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 font-semibold text-[#0B1F4D] dark:text-[#F8FAFC]">
                        <span>{s.isCurrent ? 'Current Browser Session' : 'Active Browser Session'}</span>
                        <span className="text-slate-400 font-normal">·</span>
                        <span className="text-slate-500 dark:text-slate-400 font-mono-num">{s.ip_info || 'Local'}</span>
                        {s.isCurrent && (
                          <span className="text-[11px] font-semibold text-[#2563EB] dark:text-[#06B6D4]">
                            (Active Now)
                          </span>
                        )}
                      </div>
                      {s.user_agent && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-xl">
                          {s.user_agent}
                        </div>
                      )}
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        Started: {s.created_at} · Expires: {s.expires_at}
                      </div>
                    </div>
                    {!s.isCurrent && (
                      <button
                        type="button"
                        onClick={() => revokeSession(s.tokenPrefix)}
                        className="px-3 py-1.5 rounded-xl border border-red-200 dark:border-red-900/60 text-red-600 dark:text-red-400 font-semibold hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Two-Factor Authenticator */}
        {activeTab === '2fa' && (
          <div className="p-6 max-w-xl space-y-5 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="font-display font-bold text-sm text-[#0B1F4D] dark:text-[#F8FAFC] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4]" />
                  Two-Factor Authentication (2FA)
                </h2>
                <p className="text-slate-500 dark:text-slate-400">
                  Add an extra layer of protection to your {settings?.system_name || 'QABDIID BUSNESS 1'} account.
                </p>
              </div>
              <button
                type="button"
                disabled={toggling2fa}
                onClick={toggle2FA}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  user?.two_factor_enabled
                    ? 'bg-red-600 hover:bg-red-700 text-white'
                    : 'bg-[#2563EB] hover:bg-[#1D4ED8] text-white shadow-sm'
                }`}
              >
                {toggling2fa
                  ? t('loading')
                  : user?.two_factor_enabled
                  ? 'Disable 2FA'
                  : 'Enable 2FA'}
              </button>
            </div>

            <div className="p-4 rounded-xl border border-[#E2E8F0] dark:border-slate-800 bg-[#F8FAFC] dark:bg-[#111827] space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-600 dark:text-slate-300">Status</span>
                <span
                  className={`font-semibold ${
                    user?.two_factor_enabled
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {user?.two_factor_enabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>

              {twoFactorSecret && (
                <div className="pt-2 border-t border-[#E2E8F0] dark:border-slate-800 space-y-2">
                  <div className="font-medium text-slate-700 dark:text-slate-300">
                    Authenticator Secret / Recovery Key
                  </div>
                  <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-700">
                    <code className="font-mono-num font-bold text-[#0B1F4D] dark:text-[#06B6D4] tracking-wider">
                      {twoFactorSecret}
                    </code>
                    <button
                      type="button"
                      onClick={copy2faSecret}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#2563EB]/10 text-[#2563EB] dark:bg-[#06B6D4]/15 dark:text-[#06B6D4] font-semibold hover:opacity-80"
                    >
                      {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedKey ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
