import React, { useEffect, useState, useCallback } from 'react';
import { Plus, Edit2, Trash2, X } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { User } from '../types/erp.ts';

interface AuditRow {
  id: number;
  username: string;
  action: string;
  module: string;
  record_id: string;
  details: string;
  created_at: string;
}

interface LoginRow {
  created_at: string;
  expires_at: string;
  ip_info: string;
  user_agent: string;
  is_active: number;
  username: string;
  role: string;
}

export function UsersPage() {
  const { t, user: currentUser, showToast } = useApp();
  const [tab, setTab] = useState<'users' | 'audit' | 'logins'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<string[]>([]);
  const [allPerms, setAllPerms] = useState<string[]>([]);
  const [roleDefaults, setRoleDefaults] = useState<Record<string, string[]>>({});
  const [auditLogs, setAuditLogs] = useState<AuditRow[]>([]);
  const [auditUserFilter, setAuditUserFilter] = useState('');
  const [loginHistory, setLoginHistory] = useState<LoginRow[]>([]);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<User | null>(null);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('Cashier');
  const [password, setPassword] = useState('');
  const [perms, setPerms] = useState<string[]>([]);
  const [isActive, setIsActive] = useState(true);

  const loadData = useCallback(async () => {
    try {
      const auditUrl = auditUserFilter ? `/api/audit-logs?username=${encodeURIComponent(auditUserFilter)}` : '/api/audit-logs';
      const [uRes, aRes, lRes] = await Promise.all([
        apiFetch<{ users: User[]; roles: string[]; allPermissions: string[]; roleDefaults: Record<string, string[]> }>('/api/users'),
        apiFetch<{ logs: AuditRow[] }>(auditUrl),
        apiFetch<{ history: LoginRow[] }>('/api/login-history'),
      ]);
      setUsers(uRes.users);
      setRoles(uRes.roles);
      setAllPerms(uRes.allPermissions);
      setRoleDefaults(uRes.roleDefaults);
      setAuditLogs(aRes.logs);
      setLoginHistory(lRes.history);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load users', 'error');
    }
  }, [auditUserFilter, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openNew = () => {
    setEditing(null);
    setFirstName('');
    setLastName('');
    setUsername('');
    setEmail('');
    setPhone('');
    setRole('Cashier');
    setPassword('');
    setPerms(roleDefaults['Cashier'] || []);
    setIsActive(true);
    setModalOpen(true);
  };

  const openEdit = (u: User) => {
    setEditing(u);
    setFirstName(u.first_name);
    setLastName(u.last_name);
    setUsername(u.username);
    setEmail(u.email);
    setPhone(u.phone);
    setRole(u.role);
    setPassword('');
    setPerms(u.permissions || []);
    setIsActive(u.is_active === 1);
    setModalOpen(true);
  };

  const handleRoleChange = (nextRole: string) => {
    setRole(nextRole);
    setPerms(roleDefaults[nextRole] || []);
  };

  const togglePerm = (p: string) => {
    setPerms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  const saveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editing) {
        await apiFetch(`/api/users/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            first_name: firstName,
            last_name: lastName,
            email,
            phone,
            role,
            permissions: perms,
            is_active: isActive,
            password: password || undefined,
          }),
        });
        showToast('User updated', 'success');
      } else {
        await apiFetch('/api/users', {
          method: 'POST',
          body: JSON.stringify({
            first_name: firstName,
            last_name: lastName,
            username,
            email,
            phone,
            role,
            password,
            permissions: perms,
          }),
        });
        showToast('User created', 'success');
      }
      setModalOpen(false);
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to save user', 'error');
    }
  };

  const deleteUser = async (id: number) => {
    try {
      await apiFetch(`/api/users/${id}`, { method: 'DELETE' });
      showToast('User deleted', 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to delete user', 'error');
    }
  };

  const toggleUserStatus = async (u: User) => {
    try {
      await apiFetch(`/api/users/${u.id}`, {
        method: 'PUT',
        body: JSON.stringify({ is_active: u.is_active === 1 ? false : true }),
      });
      showToast(u.is_active === 1 ? `Deactivated ${u.username}` : `Activated ${u.username}`, 'success');
      await loadData();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to update user status', 'error');
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 erp-card">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setTab('users')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${tab === 'users' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'}`}
          >
            {t('users')} ({users.length})
          </button>
          <button
            onClick={() => setTab('audit')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${tab === 'audit' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'}`}
          >
            Activity Logs ({auditLogs.length})
          </button>
          <button
            onClick={() => setTab('logins')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${tab === 'logins' ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'}`}
          >
            Login History ({loginHistory.length})
          </button>
        </div>

        {tab === 'users' && (
          <button
            onClick={openNew}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" /> Create User
          </button>
        )}
      </div>

      {tab === 'users' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">User</th>
                  <th className="text-left px-4 py-3 font-medium">{t('username')}</th>
                  <th className="text-left px-4 py-3 font-medium">Role</th>
                  <th className="text-left px-4 py-3 font-medium">Last Login</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                  <th className="text-right px-4 py-3 font-medium">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => (
                  <tr key={u.id}>
                    <td className="px-4 py-3">
                      <div className="font-semibold">{u.first_name} {u.last_name}</div>
                      <div className="text-[11px] text-slate-500">{u.email} · {u.phone}</div>
                    </td>
                    <td className="px-4 py-3 font-mono-num">{u.username}</td>
                    <td className="px-4 py-3">{u.role}</td>
                    <td className="px-4 py-3 font-mono-num text-slate-500">{u.last_login_at || '-'}</td>
                    <td className="px-4 py-3">
                      <span className={u.is_active ? 'text-emerald-700 dark:text-emerald-400 font-medium' : 'text-red-600'}>
                        {u.is_active ? t('active') : t('inactive')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center gap-1">
                        {u.id !== 1 && u.id !== currentUser?.id && (
                          <button
                            onClick={() => toggleUserStatus(u)}
                            className={`px-2 py-1 rounded border text-[11px] font-medium ${
                              u.is_active === 1
                                ? 'border-amber-200 text-amber-700 dark:border-amber-800 dark:text-amber-300'
                                : 'border-emerald-200 text-emerald-700 dark:border-emerald-800 dark:text-emerald-300'
                            }`}
                          >
                            {u.is_active === 1 ? 'Deactivate' : 'Activate'}
                          </button>
                        )}
                        <button onClick={() => openEdit(u)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {u.id !== 1 && u.id !== currentUser?.id && (
                          <button onClick={() => deleteUser(u.id)} className="p-1.5 rounded border border-slate-200 dark:border-slate-700 text-red-600">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'audit' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="px-4 py-3 border-b border-[#E2E8F0] dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <span className="font-semibold text-xs text-[#0B1F4D] dark:text-[#F8FAFC]">User Activity History</span>
            <select
              value={auditUserFilter}
              onChange={(e) => setAuditUserFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-xs"
            >
              <option value="">All Users</option>
              {users.map((u) => (
                <option key={u.id} value={u.username}>
                  @{u.username} ({u.first_name} {u.last_name})
                </option>
              ))}
            </select>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Timestamp</th>
                  <th className="text-left px-4 py-3 font-medium">User</th>
                  <th className="text-left px-4 py-3 font-medium">Module</th>
                  <th className="text-left px-4 py-3 font-medium">Action</th>
                  <th className="text-left px-4 py-3 font-medium">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {auditLogs.map((a) => (
                  <tr key={a.id}>
                    <td className="px-4 py-2.5 font-mono-num text-slate-500">{a.created_at}</td>
                    <td className="px-4 py-2.5 font-mono-num">{a.username}</td>
                    <td className="px-4 py-2.5">{a.module}</td>
                    <td className="px-4 py-2.5 font-mono-num">{a.action}</td>
                    <td className="px-4 py-2.5 text-slate-600 dark:text-slate-300">{a.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'logins' && (
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                  <th className="text-left px-4 py-3 font-medium">Login Time</th>
                  <th className="text-left px-4 py-3 font-medium">{t('username')}</th>
                  <th className="text-left px-4 py-3 font-medium">Role</th>
                  <th className="text-left px-4 py-3 font-medium">IP / Client</th>
                  <th className="text-left px-4 py-3 font-medium">{t('status')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {loginHistory.map((l, i) => (
                  <tr key={i}>
                    <td className="px-4 py-2.5 font-mono-num text-slate-500">{l.created_at}</td>
                    <td className="px-4 py-2.5 font-mono-num font-semibold">{l.username}</td>
                    <td className="px-4 py-2.5">{l.role}</td>
                    <td className="px-4 py-2.5 text-slate-500 truncate max-w-xs">{l.ip_info} · {l.user_agent}</td>
                    <td className="px-4 py-2.5">{l.is_active ? 'Active' : 'Signed Out'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form onSubmit={saveUser} className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-xl p-5 space-y-4 max-h-[90vh] overflow-y-auto text-xs erp-card">
            <div className="flex items-center justify-between pb-2 border-b border-[#E2E8F0] dark:border-slate-800">
              <h3 className="font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{editing ? `Edit User: ${editing.username}` : 'Create User'}</h3>
              <button type="button" onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input type="text" required placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
              <input type="text" required placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
              {!editing && (
                <input type="text" required placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num" />
              )}
              <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
              <input type="text" placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent" />
              <select value={role} onChange={(e) => handleRoleChange(e.target.value)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827]">
                {roles.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              <input
                type="password"
                required={!editing}
                placeholder={editing ? 'New Password (optional)' : 'Password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent col-span-2"
              />
            </div>

            {editing && (
              <label className="inline-flex items-center gap-2">
                <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} className="accent-[#2563EB]" />
                <span>{t('active')}</span>
              </label>
            )}

            <div>
              <div className="font-semibold mb-2 text-[#0B1F4D] dark:text-[#F8FAFC]">Module Permissions</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {allPerms.map((p) => (
                  <label key={p} className="inline-flex items-center gap-1.5">
                    <input type="checkbox" checked={perms.includes(p)} onChange={() => togglePerm(p)} className="accent-[#2563EB]" />
                    <span className="font-mono-num text-[11px]">{p}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button type="button" onClick={() => setModalOpen(false)} className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700">{t('cancel')}</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold transition-colors">{t('save')}</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
