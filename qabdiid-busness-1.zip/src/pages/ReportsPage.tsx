import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { Download, Printer, Search } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { exportCsv, exportExcel, exportReportPdf } from '../utils/export.ts';

const REPORT_TYPES = [
  { key: 'daily_sales', label: 'Sales Reports' },
  { key: 'purchases', label: 'Purchase Reports' },
  { key: 'inventory', label: 'Inventory Reports' },
  { key: 'low_stock', label: 'Low Stock Reports' },
  { key: 'sales_returns', label: 'Sales Return Reports' },
  { key: 'purchase_returns', label: 'Purchase Return Reports' },
  { key: 'customer_debt', label: 'Customer Reports' },
  { key: 'supplier_debt', label: 'Supplier Reports' },
  { key: 'expenses', label: 'Expense Reports' },
  { key: 'vat', label: 'VAT Reports' },
  { key: 'profit_loss', label: 'Profit & Loss Report' },
  { key: 'cash_flow', label: 'Cash Flow Report' },
  { key: 'outstanding_balances', label: 'Outstanding Balances' },
  { key: 'stock_valuation', label: 'Stock Valuation Report' },
  { key: 'monthly_sales', label: 'Monthly Sales' },
  { key: 'annual_sales', label: 'Annual Sales' },
  { key: 'employee_performance', label: 'Employee Performance' },
  { key: 'payments', label: 'Payment Reports' },
  { key: 'stock_movements', label: 'Stock Movement Reports' },
];

export function ReportsPage() {
  const { t, settings, showToast } = useApp();
  const [reportType, setReportType] = useState('daily_sales');
  const [start, setStart] = useState(() => {
    const d = new Date(Date.now() - 30 * 86400000);
    return d.toISOString().slice(0, 10);
  });
  const [end, setEnd] = useState(() => new Date().toISOString().slice(0, 10));
  const [search, setSearch] = useState('');
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);
  const [loading, setLoading] = useState(false);

  const loadReport = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiFetch<{ rows: Array<Record<string, unknown>> }>(`/api/reports/${reportType}?start=${start}&end=${end}`);
      setRows(res.rows);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Failed to load report', 'error');
    } finally {
      setLoading(false);
    }
  }, [reportType, start, end, showToast]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  const filteredRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((row) =>
      Object.values(row).some((val) => String(val ?? '').toLowerCase().includes(q))
    );
  }, [rows, search]);

  const currentTitle = REPORT_TYPES.find((r) => r.key === reportType)?.label || 'Report';
  const columns = filteredRows.length > 0 ? Object.keys(filteredRows[0]) : rows.length > 0 ? Object.keys(rows[0]) : [];

  return (
    <div className="space-y-5">
      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 space-y-3 no-print erp-card">
        <div className="flex flex-wrap items-center gap-1.5">
          {REPORT_TYPES.map((r) => (
            <button
              key={r.key}
              onClick={() => setReportType(r.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                reportType === r.key
                  ? 'bg-[#2563EB] text-white shadow-sm'
                  : 'bg-[#F8FAFC] dark:bg-[#111827] text-slate-700 dark:text-slate-300 border border-[#E2E8F0] dark:border-slate-700 hover:border-[#2563EB]/40'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
            />
            <span className="text-slate-400">–</span>
            <input
              type="date"
              value={end}
              onChange={(e) => setEnd(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent font-mono-num"
            />
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search report..."
                className="pl-8 pr-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent w-48"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => exportReportPdf(currentTitle, filteredRows, settings)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> {t('exportPdf')}
            </button>
            <button
              onClick={() => exportExcel(`qabdiid_${reportType}`, filteredRows)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" /> {t('exportExcel')}
            </button>
            <button
              onClick={() => exportCsv(`qabdiid_${reportType}`, filteredRows)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" /> {t('exportCsv')}
            </button>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs font-medium hover:bg-[#F8FAFC] dark:hover:bg-slate-800 transition-colors"
            >
              <Printer className="w-3.5 h-3.5 text-[#2563EB] dark:text-[#06B6D4]" /> Print
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card">
        <div className="px-5 py-3.5 border-b border-[#E2E8F0] dark:border-slate-800 flex items-center justify-between">
          <h2 className="font-display font-semibold text-sm text-[#0B1F4D] dark:text-[#F8FAFC]">{currentTitle}</h2>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono-num">{filteredRows.length} record(s)</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#F8FAFC] dark:bg-[#0B1F4D]/35 border-b border-[#E2E8F0] dark:border-slate-800 text-slate-500 dark:text-slate-400">
                {columns.map((col) => (
                  <th key={col} className="text-left px-4 py-3 font-medium capitalize">
                    {col.replace(/_/g, ' ')}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading ? (
                <tr>
                  <td colSpan={Math.max(1, columns.length)} className="py-10 text-center text-slate-500">
                    {t('loading')}
                  </td>
                </tr>
              ) : filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={Math.max(1, columns.length)} className="py-10 text-center text-slate-500">
                    {t('noRecords')}
                  </td>
                </tr>
              ) : (
                filteredRows.map((row, idx) => (
                  <tr key={idx}>
                    {columns.map((col) => {
                      const val = row[col];
                      const isNum = typeof val === 'number';
                      return (
                        <td key={col} className={`px-4 py-2.5 ${isNum ? 'font-mono-num' : ''}`}>
                          {isNum ? val.toLocaleString('en-US', { maximumFractionDigits: 2 }) : String(val ?? '-')}
                        </td>
                      );
                    })}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
