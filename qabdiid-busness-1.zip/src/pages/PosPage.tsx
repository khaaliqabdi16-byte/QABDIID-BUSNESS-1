import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  Search,
  Plus,
  Minus,
  Trash2,
  PauseCircle,
  PlayCircle,
  Printer,
  CheckCircle2,
  Package,
  UserPlus,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { apiFetch } from '../utils/api.ts';
import { formatMoney, generateSaleReceiptPdf } from '../utils/export.ts';
import { Category, CurrencyCode, Customer, Product, Sale, SaleItem } from '../types/erp.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';

interface CartItem {
  product: Product;
  quantity: number;
  unit_price: number;
  discount_amount: number;
}

export function PosPage() {
  const { t, settings, currencies, isOnline, queueOfflineSale, refreshNotifications, showToast } = useApp();

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [heldSales, setHeldSales] = useState<Sale[]>([]);

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<number | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerId, setCustomerId] = useState<number>(1);
  const [currency, setCurrency] = useState<CurrencyCode>('ETB');
  const [overallDiscount, setOverallDiscount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [paidAmount, setPaidAmount] = useState<string>('');
  const [splitCash, setSplitCash] = useState(0);
  const [splitBank, setSplitBank] = useState(0);
  const [splitMobile, setSplitMobile] = useState(0);
  const [splitCredit, setSplitCredit] = useState(0);

  const [submitting, setSubmitting] = useState(false);
  const [heldModalOpen, setHeldModalOpen] = useState(false);
  const [quickCustOpen, setQuickCustOpen] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [receiptData, setReceiptData] = useState<{ sale: Sale; items: SaleItem[] } | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  const loadPosData = useCallback(async () => {
    try {
      const [pRes, cRes, custRes, heldRes] = await Promise.all([
        apiFetch<{ products: Product[] }>('/api/products?active=1'),
        apiFetch<{ categories: Category[] }>('/api/categories'),
        apiFetch<{ customers: Customer[] }>('/api/customers'),
        apiFetch<{ sales: Sale[] }>('/api/sales?status=Held'),
      ]);
      setProducts(pRes.products);
      setCategories(cRes.categories);
      setCustomers(custRes.customers);
      setHeldSales(heldRes.sales);
      localStorage.setItem('qabdiid_pos_products_cache', JSON.stringify(pRes.products));
      localStorage.setItem('qabdiid_pos_customers_cache', JSON.stringify(custRes.customers));
    } catch {
      const cachedProds = localStorage.getItem('qabdiid_pos_products_cache');
      const cachedCusts = localStorage.getItem('qabdiid_pos_customers_cache');
      if (cachedProds) setProducts(JSON.parse(cachedProds));
      if (cachedCusts) setCustomers(JSON.parse(cachedCusts));
    }
  }, []);

  useEffect(() => {
    loadPosData();
  }, [loadPosData]);

  const exchangeRate = currencies.find((c) => c.code === currency)?.exchange_rate_to_etb || 1;

  const addToCart = (product: Product) => {
    const unitPriceInCurrency = Math.round((product.selling_price / exchangeRate) * 100) / 100;
    setCart((prev) => {
      const existing = prev.find((c) => c.product.id === product.id);
      if (existing) {
        return prev.map((c) => (c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c));
      }
      return [...prev, { product, quantity: 1, unit_price: unitPriceInCurrency, discount_amount: 0 }];
    });
  };

  // Switch currency updates cart unit prices cleanly
  const handleCurrencyChange = (nextCurr: CurrencyCode) => {
    const nextRate = currencies.find((c) => c.code === nextCurr)?.exchange_rate_to_etb || 1;
    setCurrency(nextCurr);
    setCart((prev) =>
      prev.map((item) => ({
        ...item,
        unit_price: Math.round((item.product.selling_price / nextRate) * 100) / 100,
      }))
    );
  };

  const handleBarcodeEnter = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key !== 'Enter') return;
    const q = search.trim().toLowerCase();
    if (!q) return;
    const exact = products.find((p) => p.barcode.toLowerCase() === q || p.sku.toLowerCase() === q);
    if (exact) {
      addToCart(exact);
      setSearch('');
      showToast(`Added ${exact.name}`, 'success');
    }
  };

  const filteredProducts = products.filter((p) => {
    if (selectedCat && p.category_id !== selectedCat) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || p.barcode.toLowerCase().includes(q);
  });

  // Totals
  const subtotal = cart.reduce((s, item) => s + Math.max(0, item.quantity * item.unit_price - item.discount_amount), 0);
  const vatTotal = cart.reduce((s, item) => {
    const lineNet = Math.max(0, item.quantity * item.unit_price - item.discount_amount);
    return s + lineNet * (item.product.vat_rate / 100);
  }, 0);
  const grandTotal = Math.max(0, Math.round((subtotal - overallDiscount + vatTotal) * 100) / 100);

  const effectivePaid =
    paymentMethod === 'Credit'
      ? 0
      : paymentMethod === 'Split'
      ? splitCash + splitBank + splitMobile
      : paidAmount === ''
      ? grandTotal
      : Number(paidAmount);

  const balance = Math.max(0, Math.round((grandTotal - effectivePaid) * 100) / 100);

  const submitSale = async (options: { isHeld?: boolean; printAfter?: boolean; downloadPdf?: boolean }) => {
    if (cart.length === 0) {
      showToast(t('emptyCart'), 'error');
      return;
    }

    const payload = {
      customer_id: customerId,
      currency,
      discount_amount: overallDiscount,
      payment_method: paymentMethod,
      paid_amount: effectivePaid,
      split_details:
        paymentMethod === 'Split'
          ? { cash: splitCash, bank: splitBank, mobile: splitMobile, credit: splitCredit }
          : undefined,
      is_held: Boolean(options.isHeld),
      items: cart.map((c) => ({
        product_id: c.product.id,
        quantity: c.quantity,
        unit_price: c.unit_price,
        discount_amount: c.discount_amount,
        vat_rate: c.product.vat_rate,
      })),
    };

    if (!isOnline && !options.isHeld) {
      queueOfflineSale(payload);
      setCart([]);
      setOverallDiscount(0);
      setPaidAmount('');
      showToast('Offline: Sale queued locally and will sync automatically when online', 'success');
      return;
    }

    setSubmitting(true);
    try {
      const res = await apiFetch<{ id: number; invoice_number: string }>('/api/sales', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      showToast(`${options.isHeld ? 'Held' : 'Completed'} ${res.invoice_number}`, 'success');
      setCart([]);
      setOverallDiscount(0);
      setPaidAmount('');
      setSplitCash(0);
      setSplitBank(0);
      setSplitMobile(0);
      setSplitCredit(0);

      if ((options.printAfter || options.downloadPdf) && !options.isHeld) {
        const detail = await apiFetch<{ sale: Sale; items: SaleItem[] }>(`/api/sales/${res.id}`);
        if (options.downloadPdf) {
          generateSaleReceiptPdf(detail.sale, detail.items, settings);
        }
        if (options.printAfter) {
          setReceiptData(detail);
        }
      }

      await Promise.all([loadPosData(), refreshNotifications()]);
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Checkout failed', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResumeHeld = async (sale: Sale) => {
    try {
      const detail = await apiFetch<{ sale: Sale; items: SaleItem[] }>(`/api/sales/${sale.id}`);
      const restored: CartItem[] = [];
      for (const si of detail.items) {
        const prod = products.find((p) => p.id === si.product_id);
        if (prod) {
          restored.push({
            product: prod,
            quantity: si.quantity,
            unit_price: si.unit_price,
            discount_amount: si.discount_amount,
          });
        }
      }
      await apiFetch(`/api/sales/${sale.id}/cancel`, { method: 'POST' });
      setCart(restored);
      setCustomerId(sale.customer_id || 1);
      setCurrency(sale.currency);
      setHeldModalOpen(false);
      await loadPosData();
      showToast(`Loaded held sale ${sale.invoice_number} into cart`, 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to resume sale', 'error');
    }
  };

  const handleQuickCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;
    try {
      const res = await apiFetch<{ id: number }>('/api/customers', {
        method: 'POST',
        body: JSON.stringify({ full_name: newCustName, phone: newCustPhone }),
      });
      await loadPosData();
      setCustomerId(res.id);
      setNewCustName('');
      setNewCustPhone('');
      setQuickCustOpen(false);
      showToast('Customer added', 'success');
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'Unable to add customer', 'error');
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
      {/* Left: Product Catalog & Barcode Scanner */}
      <div className="xl:col-span-7 space-y-4">
        <div className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card space-y-3">
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-[#2563EB] dark:text-[#06B6D4] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={handleBarcodeEnter}
                placeholder={t('searchProductsPlaceholder')}
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-[#F8FAFC] dark:bg-[#111827] text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              />
            </div>

            <button
              onClick={() => setHeldModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <PauseCircle className="w-4 h-4 text-amber-600" />
              {t('heldSales')} ({heldSales.length})
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setSelectedCat(null)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap ${
                selectedCat === null
                  ? 'bg-[#2563EB] text-white shadow-xs'
                  : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {t('allCategories')}
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCat(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap ${
                  selectedCat === cat.id
                    ? 'bg-[#2563EB] text-white shadow-xs'
                    : 'bg-[#F8FAFC] dark:bg-[#111827] border border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {filteredProducts.map((p) => {
            const displayPrice = Math.round((p.selling_price / exchangeRate) * 100) / 100;
            const outOfStock = p.current_stock <= 0 && !settings?.allow_negative_stock;
            return (
              <button
                key={p.id}
                type="button"
                disabled={outOfStock}
                onClick={() => addToCart(p)}
                className="text-left bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl overflow-hidden erp-card hover:border-[#2563EB] dark:hover:border-[#06B6D4] transition-all disabled:opacity-50 flex flex-col"
              >
                <div className="aspect-[4/3] w-full bg-[#F8FAFC] dark:bg-[#111827] overflow-hidden flex items-center justify-center">
                  {p.image_url ? (
                    <img
                      src={p.image_url}
                      alt={p.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Package className="w-8 h-8 text-slate-400" />
                  )}
                </div>
                <div className="p-3 flex-1 flex flex-col justify-between w-full">
                  <div>
                    <div className="text-xs font-semibold text-[#111827] dark:text-[#F8FAFC] line-clamp-2">
                      {p.name}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono-num mt-0.5">
                      {p.sku} · {p.current_stock} {p.unit}
                    </div>
                  </div>
                  <div className="mt-2 font-mono-num text-sm font-bold text-[#2563EB] dark:text-[#06B6D4]">
                    {formatMoney(displayPrice, currency)}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right: Cart & Payment Terminal */}
      <div className="xl:col-span-5 bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl p-4 erp-card space-y-4">
        <div className="flex items-center justify-between border-b border-[#E2E8F0] dark:border-slate-800 pb-3">
          <h2 className="font-display text-sm font-bold text-[#0B1F4D] dark:text-[#F8FAFC]">{t('cart')}</h2>
          <div className="flex items-center gap-2">
            <select
              value={currency}
              onChange={(e) => handleCurrencyChange(e.target.value as CurrencyCode)}
              className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono-num"
            >
              {currencies.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.code}
                </option>
              ))}
            </select>
            {cart.length > 0 && (
              <button
                onClick={() => setCart([])}
                className="text-xs text-red-600 hover:underline whitespace-nowrap"
              >
                {t('clearCart')}
              </button>
            )}
          </div>
        </div>

        {/* Customer Selector */}
        <div className="flex items-center gap-2">
          <select
            value={customerId}
            onChange={(e) => setCustomerId(Number(e.target.value))}
            className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
          >
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.full_name} {c.phone ? `(${c.phone})` : ''}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setQuickCustOpen(true)}
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
            title={t('addCustomer')}
          >
            <UserPlus className="w-4 h-4" />
          </button>
        </div>

        {/* Cart Items */}
        <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
          {cart.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500 dark:text-slate-400">
              {t('emptyCart')}
            </div>
          ) : (
            cart.map((item) => {
              const lineNet = Math.max(0, item.quantity * item.unit_price - item.discount_amount);
              const lineVat = lineNet * (item.product.vat_rate / 100);
              const lineSub = lineNet + lineVat;
              return (
                <div key={item.product.id} className="py-2.5 space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {item.product.name}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        {item.product.sku} · {item.product.unit} · VAT {item.product.vat_rate}%
                      </div>
                    </div>
                    <button
                      onClick={() => setCart((prev) => prev.filter((c) => c.product.id !== item.product.id))}
                      className="text-slate-400 hover:text-red-600 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() =>
                          setCart((prev) =>
                            prev.map((c) =>
                              c.product.id === item.product.id ? { ...c, quantity: Math.max(1, c.quantity - 1) } : c
                            )
                          )
                        }
                        className="p-1 rounded border border-slate-200 dark:border-slate-700"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <input
                        type="number"
                        min={1}
                        value={item.quantity}
                        onChange={(e) => {
                          const v = Math.max(1, Number(e.target.value) || 1);
                          setCart((prev) => prev.map((c) => (c.product.id === item.product.id ? { ...c, quantity: v } : c)));
                        }}
                        className="w-12 text-center py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                      />
                      <button
                        onClick={() =>
                          setCart((prev) =>
                            prev.map((c) => (c.product.id === item.product.id ? { ...c, quantity: c.quantity + 1 } : c))
                          )
                        }
                        className="p-1 rounded border border-slate-200 dark:border-slate-700"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min={0}
                        step="0.01"
                        value={item.unit_price}
                        onChange={(e) => {
                          const p = Math.max(0, Number(e.target.value) || 0);
                          setCart((prev) => prev.map((c) => (c.product.id === item.product.id ? { ...c, unit_price: p } : c)));
                        }}
                        className="w-20 text-right px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                        title={t('price')}
                      />
                      <span className="font-mono-num font-semibold w-24 text-right">
                        {formatMoney(lineSub, currency)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Summary & Payment Calculation */}
        <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-500">{t('subtotal')}</span>
            <span className="font-mono-num">{formatMoney(subtotal, currency)}</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="text-slate-500">{t('discount')}</span>
            <input
              type="number"
              min={0}
              step="0.01"
              value={overallDiscount}
              onChange={(e) => setOverallDiscount(Math.max(0, Number(e.target.value) || 0))}
              className="w-28 text-right px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
            />
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">{t('vat')}</span>
            <span className="font-mono-num">{formatMoney(vatTotal, currency)}</span>
          </div>
          <div className="flex justify-between text-base font-bold pt-2 border-t border-[#E2E8F0] dark:border-slate-800">
            <span>{t('grandTotal')}</span>
            <span className="font-mono-num text-[#2563EB] dark:text-[#06B6D4]">
              {formatMoney(grandTotal, currency)}
            </span>
          </div>
        </div>

        {/* Payment Method */}
        <div className="space-y-2.5">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
            {t('paymentMethod')}
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[
              { key: 'Cash', label: t('cash') },
              { key: 'Card', label: t('cardPayment') },
              { key: 'Bank Transfer', label: t('bankTransfer') },
              { key: 'Mobile Money', label: t('mobileMoney') },
              { key: 'Credit', label: t('creditDebt') },
              { key: 'Split', label: t('splitPayment') },
            ].map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => setPaymentMethod(m.key)}
                className={`px-2.5 py-2 rounded-xl text-xs font-medium border transition-all whitespace-nowrap ${
                  paymentMethod === m.key
                    ? 'bg-[#2563EB] border-[#2563EB] text-white shadow-xs'
                    : 'border-[#E2E8F0] dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-[#F8FAFC] dark:hover:bg-slate-800'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {paymentMethod === 'Split' ? (
            <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">{t('cash')}</span>
                <input
                  type="number"
                  min={0}
                  value={splitCash}
                  onChange={(e) => setSplitCash(Number(e.target.value) || 0)}
                  className="w-full px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <span className="text-slate-500 block mb-1">{t('bankTransfer')}</span>
                <input
                  type="number"
                  min={0}
                  value={splitBank}
                  onChange={(e) => setSplitBank(Number(e.target.value) || 0)}
                  className="w-full px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <span className="text-slate-500 block mb-1">{t('mobileMoney')}</span>
                <input
                  type="number"
                  min={0}
                  value={splitMobile}
                  onChange={(e) => setSplitMobile(Number(e.target.value) || 0)}
                  className="w-full px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
              <div>
                <span className="text-slate-500 block mb-1">{t('creditDebt')}</span>
                <input
                  type="number"
                  min={0}
                  value={splitCredit}
                  onChange={(e) => setSplitCredit(Number(e.target.value) || 0)}
                  className="w-full px-2 py-1.5 rounded border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            </div>
          ) : (
            paymentMethod !== 'Credit' && (
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="text-slate-500">{t('amountPaid')}</span>
                <input
                  type="number"
                  min={0}
                  step="0.01"
                  value={paidAmount}
                  placeholder={grandTotal.toFixed(2)}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  className="w-36 text-right px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-transparent font-mono-num"
                />
              </div>
            )
          )}

          <div className="flex justify-between text-xs font-medium">
            <span className="text-slate-500">{t('remainingBalance')}</span>
            <span className={`font-mono-num ${balance > 0 ? 'text-amber-600 font-semibold' : 'text-slate-600 dark:text-slate-400'}`}>
              {formatMoney(balance, currency)}
            </span>
          </div>
        </div>

        {/* POS Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            type="button"
            disabled={submitting || cart.length === 0}
            onClick={() => submitSale({})}
            className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-semibold shadow-sm disabled:opacity-50 whitespace-nowrap"
          >
            <CheckCircle2 className="w-4 h-4" />
            {t('saveSale')}
          </button>
          <button
            type="button"
            disabled={submitting || cart.length === 0}
            onClick={() => submitSale({ printAfter: true, downloadPdf: true })}
            className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#0B1F4D] hover:bg-[#132E6E] text-white text-xs font-semibold shadow-sm disabled:opacity-50 whitespace-nowrap"
          >
            <Printer className="w-4 h-4 text-[#06B6D4]" />
            {t('saveAndPrint')}
          </button>
          <button
            type="button"
            disabled={submitting || cart.length === 0 || !isOnline}
            onClick={() => submitSale({ isHeld: true })}
            className="inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap"
          >
            <PauseCircle className="w-4 h-4" />
            {t('holdSale')}
          </button>
          <button
            type="button"
            disabled={cart.length === 0}
            onClick={() => {
              setCart([]);
              setOverallDiscount(0);
              setPaidAmount('');
            }}
            className="inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 text-xs font-medium hover:bg-red-50 dark:hover:bg-red-950/30 disabled:opacity-50 whitespace-nowrap"
          >
            <X className="w-4 h-4" />
            {t('cancelSale')}
          </button>
        </div>
      </div>

      {/* Held Sales Modal */}
      {heldModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl w-full max-w-lg p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-3">
              <h3 className="font-semibold text-sm">{t('heldSales')}</h3>
              <button onClick={() => setHeldModalOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {heldSales.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-500">{t('noRecords')}</div>
              ) : (
                heldSales.map((hs) => (
                  <div
                    key={hs.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs"
                  >
                    <div>
                      <div className="font-mono-num font-semibold">{hs.invoice_number}</div>
                      <div className="text-slate-500">
                        {hs.customer_name || 'Walk-In'} · {formatMoney(hs.grand_total, hs.currency)}
                      </div>
                    </div>
                    <button
                      onClick={() => handleResumeHeld(hs)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#2563EB] text-white font-medium hover:bg-[#1D4ED8]"
                    >
                      <PlayCircle className="w-3.5 h-3.5" />
                      {t('resumeSale')}
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Quick Customer Modal */}
      {quickCustOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0B1F4D]/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleQuickCustomer}
            className="bg-white dark:bg-[#161F33] border border-[#E2E8F0] dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 space-y-4 shadow-xl"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">{t('addCustomer')}</h3>
              <button type="button" onClick={() => setQuickCustOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newCustName}
                onChange={(e) => setNewCustName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1">Phone</label>
              <input
                type="text"
                value={newCustPhone}
                onChange={(e) => setNewCustPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 bg-transparent text-sm"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setQuickCustOpen(false)}
                className="px-3 py-2 rounded-xl border border-[#E2E8F0] dark:border-slate-700 text-xs"
              >
                {t('cancel')}
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] text-white text-xs font-medium">
                {t('save')}
              </button>
            </div>
          </form>
        </div>
      )}

      {receiptData && (
        <ReceiptModal
          sale={receiptData.sale}
          items={receiptData.items}
          settings={settings}
          onClose={() => setReceiptData(null)}
        />
      )}
    </div>
  );
}
