import { ThemeMode } from '../types/erp.ts';

export interface LiquidThemeMeta {
  id: ThemeMode;
  name: string;
  isDark: boolean;
  previewBg: string;
  previewGlass: string;
  previewAccent: string;
  previewSidebar: string;
  previewBorder: string;
  previewText: string;
}

export const LIQUID_THEMES: LiquidThemeMeta[] = [
  {
    id: 'light-glass',
    name: 'Light Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #F1F5F9 0%, #E0E7FF 52%, #E0F2FE 100%)',
    previewGlass: 'rgba(255, 255, 255, 0.72)',
    previewAccent: '#2563EB',
    previewSidebar: '#0B1F4D',
    previewBorder: 'rgba(255, 255, 255, 0.9)',
    previewText: '#0F172A',
  },
  {
    id: 'dark-glass',
    name: 'Dark Glass',
    isDark: true,
    previewBg: 'linear-gradient(135deg, #090D18 0%, #0F172A 55%, #172554 100%)',
    previewGlass: 'rgba(15, 23, 42, 0.76)',
    previewAccent: '#3B82F6',
    previewSidebar: '#070E24',
    previewBorder: 'rgba(148, 163, 184, 0.25)',
    previewText: '#F8FAFC',
  },
  {
    id: 'aqua-glass',
    name: 'Aqua Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #ECFEFF 0%, #CFFAFE 50%, #BAE6FD 100%)',
    previewGlass: 'rgba(240, 253, 255, 0.68)',
    previewAccent: '#0891B2',
    previewSidebar: '#083344',
    previewBorder: 'rgba(165, 243, 252, 0.9)',
    previewText: '#083344',
  },
  {
    id: 'emerald-glass',
    name: 'Emerald Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 50%, #CCFBF1 100%)',
    previewGlass: 'rgba(242, 254, 249, 0.68)',
    previewAccent: '#059669',
    previewSidebar: '#064E3B',
    previewBorder: 'rgba(167, 243, 208, 0.9)',
    previewText: '#064E3B',
  },
  {
    id: 'crystal-glass',
    name: 'Crystal Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #F5F3FF 0%, #EDE9FE 48%, #E0E7FF 100%)',
    previewGlass: 'rgba(255, 255, 255, 0.64)',
    previewAccent: '#4F46E5',
    previewSidebar: '#1E1B4B',
    previewBorder: 'rgba(224, 231, 255, 0.92)',
    previewText: '#1E1B4B',
  },
  {
    id: 'golden-glass',
    name: 'Golden Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #FFFBEB 0%, #FEF3C7 50%, #FDE68A 100%)',
    previewGlass: 'rgba(255, 252, 240, 0.7)',
    previewAccent: '#D97706',
    previewSidebar: '#451A03',
    previewBorder: 'rgba(253, 230, 138, 0.9)',
    previewText: '#451A03',
  },
  {
    id: 'rose-glass',
    name: 'Rose Glass',
    isDark: false,
    previewBg: 'linear-gradient(135deg, #FFF1F2 0%, #FFE4E6 50%, #FCE7F3 100%)',
    previewGlass: 'rgba(255, 247, 248, 0.7)',
    previewAccent: '#E11D48',
    previewSidebar: '#4C0519',
    previewBorder: 'rgba(254, 205, 211, 0.9)',
    previewText: '#4C0519',
  },
  {
    id: 'ocean-glass',
    name: 'Ocean Glass',
    isDark: true,
    previewBg: 'linear-gradient(135deg, #04152D 0%, #0A2E5C 52%, #0E7490 100%)',
    previewGlass: 'rgba(7, 36, 74, 0.72)',
    previewAccent: '#06B6D4',
    previewSidebar: '#041B3A',
    previewBorder: 'rgba(56, 189, 248, 0.32)',
    previewText: '#F0F9FF',
  },
];

export const LIQUID_THEME_MAP: Record<ThemeMode, LiquidThemeMeta> = LIQUID_THEMES.reduce(
  (acc, item) => {
    acc[item.id] = item;
    return acc;
  },
  {} as Record<ThemeMode, LiquidThemeMeta>
);

export function normalizeTheme(raw: string | null): ThemeMode {
  if (raw === 'light') return 'light-glass';
  if (raw === 'dark') return 'dark-glass';
  if (raw && raw in LIQUID_THEME_MAP) {
    return raw as ThemeMode;
  }
  return 'light-glass';
}
