import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { CurrencyCode, Purchase, Sale, SaleItem, Settings } from '../types/erp.ts';

export function formatMoney(amount: number, currency: CurrencyCode | string = 'ETB', symbol?: string): string {
  const val = Number(amount || 0);
  const formatted = val.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  if (currency === 'USD') return `$${formatted}`;
  if (symbol) return `${symbol}${formatted}`;
  return `${formatted} ${currency || 'ETB'}`;
}

export function exportExcel(filename: string, rows: Record<string, unknown>[]): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
  XLSX.writeFile(workbook, `${filename}.xlsx`);
}

export function exportCsv(filename: string, rows: Record<string, unknown>[]): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

export function exportReportPdf(title: string, rows: Record<string, unknown>[], settings: Settings | null): void {
  const doc = new jsPDF({ orientation: 'landscape' });
  doc.setFontSize(14);
  doc.text(settings?.business_name || 'QABDIID BUSNESS 1', 14, 15);
  doc.setFontSize(11);
  doc.text(title, 14, 22);
  doc.setFontSize(8);
  doc.text(`${settings?.address || ''} | ${settings?.phone || ''} | Generated: ${new Date().toLocaleString('en-GB', { timeZone: 'Africa/Addis_Ababa' })}`, 14, 28);

  if (rows.length > 0) {
    const headers = Object.keys(rows[0]);
    const body = rows.map((r) => headers.map((h) => String(r[h] ?? '')));
    autoTable(doc, {
      startY: 33,
      head: [headers],
      body,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [5, 150, 105] },
    });
  } else {
    doc.text('No records found for selected criteria.', 14, 40);
  }
  doc.save(`${title.toLowerCase().replace(/[^a-z0-9]+/g, '_')}.pdf`);
}

export function generateSaleReceiptPdf(sale: Sale, items: SaleItem[], settings: Settings | null): void {
  const doc = new jsPDF({ unit: 'mm', format: [80, 210] });
  let y = 10;

  doc.setFontSize(12);
  doc.text(settings?.business_name || 'QABDIID BUSNESS 1', 40, y, { align: 'center' });
  y += 5;
  doc.setFontSize(7.5);
  if (settings?.address) {
    doc.text(settings.address, 40, y, { align: 'center' });
    y += 4;
  }
  if (settings?.phone) {
    doc.text(`Tel: ${settings.phone}`, 40, y, { align: 'center' });
    y += 4;
  }
  if (settings?.tin) {
    doc.text(`TIN: ${settings.tin}`, 40, y, { align: 'center' });
    y += 4;
  }

  doc.line(5, y, 75, y);
  y += 4;

  doc.setFontSize(8);
  doc.text(`Invoice: ${sale.invoice_number}`, 5, y);
  y += 4;
  doc.text(`Date: ${sale.created_at}`, 5, y);
  y += 4;
  doc.text(`Cashier: ${sale.created_by}`, 5, y);
  y += 4;
  doc.text(`Customer: ${sale.customer_name || 'Walk-In Customer'}`, 5, y);
  y += 4;
  doc.text(`Payment: ${sale.payment_method} (${sale.status})`, 5, y);
  y += 3;

  doc.line(5, y, 75, y);
  y += 4;

  doc.setFontSize(7.5);
  for (const item of items) {
    doc.text(`${item.product_name}`, 5, y);
    y += 3.5;
    doc.text(`${item.quantity} ${item.unit} x ${item.unit_price.toFixed(2)}`, 7, y);
    doc.text(`${item.subtotal.toFixed(2)}`, 75, y, { align: 'right' });
    y += 4.5;
  }

  doc.line(5, y, 75, y);
  y += 4;

  doc.text('Subtotal:', 5, y);
  doc.text(formatMoney(sale.subtotal, sale.currency), 75, y, { align: 'right' });
  y += 4;
  if (sale.discount_amount > 0) {
    doc.text('Discount:', 5, y);
    doc.text(`-${formatMoney(sale.discount_amount, sale.currency)}`, 75, y, { align: 'right' });
    y += 4;
  }
  doc.text('VAT:', 5, y);
  doc.text(formatMoney(sale.vat_amount, sale.currency), 75, y, { align: 'right' });
  y += 4.5;

  doc.setFontSize(9.5);
  doc.text('TOTAL:', 5, y);
  doc.text(formatMoney(sale.grand_total, sale.currency), 75, y, { align: 'right' });
  y += 5;

  doc.setFontSize(8);
  doc.text('Paid:', 5, y);
  doc.text(formatMoney(sale.paid_amount, sale.currency), 75, y, { align: 'right' });
  y += 4;
  doc.text('Balance:', 5, y);
  doc.text(formatMoney(sale.balance_amount, sale.currency), 75, y, { align: 'right' });
  y += 6;

  doc.line(5, y, 75, y);
  y += 5;
  doc.setFontSize(7);
  const footer = settings?.receipt_footer || 'Thank you for shopping with QABDIID BUSNESS 1!';
  const splitFooter = doc.splitTextToSize(footer, 68);
  doc.text(splitFooter, 40, y, { align: 'center' });

  doc.save(`${sale.invoice_number}_receipt.pdf`);
}

export function generatePurchaseVoucherPdf(
  purchase: Purchase,
  items: Array<{ product_name: string; sku: string; unit: string; quantity: number; purchase_price: number; vat_amount: number; subtotal: number }>,
  settings: Settings | null
): void {
  const doc = new jsPDF();
  doc.setFontSize(15);
  doc.text(settings?.business_name || 'QABDIID BUSNESS 1', 14, 16);
  doc.setFontSize(11);
  doc.text(`Purchase Voucher: ${purchase.purchase_number}`, 14, 24);
  doc.setFontSize(9);
  doc.text(`Date: ${purchase.purchase_date} | Supplier: ${purchase.supplier_name || '-'} | Status: ${purchase.status}`, 14, 31);

  autoTable(doc, {
    startY: 37,
    head: [['Product', 'SKU', 'Qty', 'Unit', 'Unit Cost', 'VAT', 'Subtotal']],
    body: items.map((i) => [
      i.product_name,
      i.sku,
      String(i.quantity),
      i.unit,
      formatMoney(i.purchase_price, purchase.currency),
      formatMoney(i.vat_amount, purchase.currency),
      formatMoney(i.subtotal, purchase.currency),
    ]),
    headStyles: { fillColor: [5, 150, 105] },
  });

  const finalY = (doc as unknown as { lastAutoTable?: { finalY?: number } }).lastAutoTable?.finalY || 100;
  doc.setFontSize(10);
  doc.text(`Grand Total: ${formatMoney(purchase.grand_total, purchase.currency)}`, 14, finalY + 10);
  doc.text(`Paid: ${formatMoney(purchase.paid_amount, purchase.currency)} | Balance: ${formatMoney(purchase.balance_amount, purchase.currency)}`, 14, finalY + 17);
  doc.save(`${purchase.purchase_number}_voucher.pdf`);
}

export function generateSaleReturnPdf(
  saleReturn: {
    return_number: string;
    invoice_number: string;
    return_date: string;
    customer_name?: string;
    refund_method: string;
    total_refund: number;
    reason?: string;
    status?: string;
    created_by: string;
  },
  items: Array<{ product_name: string; quantity: number; unit_price: number; vat_amount: number; subtotal: number }>,
  settings: Settings | null
): void {
  const doc = new jsPDF({ unit: 'mm', format: [80, 210] });
  let y = 10;

  doc.setFontSize(12);
  doc.text(settings?.business_name || 'QABDIID BUSNESS 1', 40, y, { align: 'center' });
  y += 5;
  doc.setFontSize(9);
  doc.text('SALES RETURN RECEIPT', 40, y, { align: 'center' });
  y += 4;
  doc.setFontSize(7.5);
  if (settings?.phone) {
    doc.text(`Tel: ${settings.phone}`, 40, y, { align: 'center' });
    y += 4;
  }

  doc.line(5, y, 75, y);
  y += 4;
  doc.setFontSize(8);
  doc.text(`Return #: ${saleReturn.return_number}`, 5, y);
  y += 4;
  doc.text(`Invoice #: ${saleReturn.invoice_number}`, 5, y);
  y += 4;
  doc.text(`Date: ${saleReturn.return_date}`, 5, y);
  y += 4;
  doc.text(`Customer: ${saleReturn.customer_name || 'Walk-In'}`, 5, y);
  y += 4;
  doc.text(`Method: ${saleReturn.refund_method} (${saleReturn.status || 'Refunded'})`, 5, y);
  y += 4;
  if (saleReturn.reason) {
    doc.text(`Reason: ${saleReturn.reason}`, 5, y);
    y += 4;
  }

  doc.line(5, y, 75, y);
  y += 4;

  doc.setFontSize(7.5);
  for (const item of items) {
    doc.text(`${item.product_name}`, 5, y);
    y += 3.5;
    doc.text(`${item.quantity} x ${Number(item.unit_price).toFixed(2)}`, 7, y);
    doc.text(`${Number(item.subtotal).toFixed(2)}`, 75, y, { align: 'right' });
    y += 4.5;
  }

  doc.line(5, y, 75, y);
  y += 5;
  doc.setFontSize(9.5);
  doc.text('TOTAL REFUND:', 5, y);
  doc.text(formatMoney(saleReturn.total_refund, 'ETB'), 75, y, { align: 'right' });
  y += 6;
  doc.setFontSize(7);
  doc.text(`Processed by: ${saleReturn.created_by}`, 5, y);
  doc.save(`${saleReturn.return_number}_return_receipt.pdf`);
}
