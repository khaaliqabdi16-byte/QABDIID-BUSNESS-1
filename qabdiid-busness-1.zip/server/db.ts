import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';

const DB_PATH = path.resolve(process.cwd(), 'qabdiid_erp.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export const ROLES = [
  'Super Administrator',
  'Administrator',
  'Manager',
  'Accountant',
  'Cashier',
  'Inventory Manager',
  'Salesperson',
] as const;

export type UserRole = (typeof ROLES)[number];

export const ALL_PERMISSIONS = [
  'dashboard.view',
  'pos.use',
  'sales.view',
  'sales.create',
  'sales.manage',
  'sales.delete',
  'sales.return',
  'purchases.view',
  'purchases.create',
  'purchases.return',
  'catalog.view',
  'catalog.manage',
  'inventory.view',
  'inventory.manage',
  'people.view',
  'people.manage',
  'expenses.view',
  'expenses.manage',
  'accounting.view',
  'accounting.manage',
  'reports.view',
  'users.manage',
  'settings.manage',
  'backup.manage',
] as const;

export type Permission = (typeof ALL_PERMISSIONS)[number];

export const ROLE_DEFAULT_PERMISSIONS: Record<string, Permission[]> = {
  'Super Administrator': [...ALL_PERMISSIONS],
  Administrator: [...ALL_PERMISSIONS],
  Manager: [
    'dashboard.view',
    'pos.use',
    'sales.view',
    'sales.create',
    'sales.manage',
    'sales.delete',
    'sales.return',
    'purchases.view',
    'purchases.create',
    'purchases.return',
    'catalog.view',
    'catalog.manage',
    'inventory.view',
    'inventory.manage',
    'people.view',
    'people.manage',
    'expenses.view',
    'expenses.manage',
    'accounting.view',
    'reports.view',
  ],
  Accountant: [
    'dashboard.view',
    'sales.view',
    'purchases.view',
    'people.view',
    'people.manage',
    'expenses.view',
    'expenses.manage',
    'accounting.view',
    'accounting.manage',
    'reports.view',
  ],
  Cashier: ['pos.use', 'sales.view', 'sales.create', 'catalog.view', 'people.view'],
  'Inventory Manager': [
    'dashboard.view',
    'catalog.view',
    'catalog.manage',
    'inventory.view',
    'inventory.manage',
    'purchases.view',
    'purchases.create',
    'purchases.return',
    'reports.view',
  ],
  Salesperson: [
    'dashboard.view',
    'pos.use',
    'sales.view',
    'sales.create',
    'catalog.view',
    'people.view',
    'people.manage',
  ],
};

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

export function addisDateTime(): string {
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Africa/Addis_Ababa',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(new Date());
  const map: Record<string, string> = {};
  for (const p of parts) {
    if (p.type !== 'literal') map[p.type] = p.value;
  }
  return `${map.year}-${map.month}-${map.day} ${map.hour}:${map.minute}:${map.second}`;
}

export function addisDate(offsetDays = 0): string {
  const d = new Date(Date.now() + offsetDays * 86400000);
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Africa/Addis_Ababa',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(d);
  const map: Record<string, string> = {};
  for (const p of parts) {
    if (p.type !== 'literal') map[p.type] = p.value;
  }
  return `${map.year}-${map.month}-${map.day}`;
}

export function initDatabase(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      business_name TEXT NOT NULL DEFAULT 'QABDIID BUSNESS 1',
      system_name TEXT NOT NULL DEFAULT 'QABDIID BUSNESS 1',
      logo_url TEXT DEFAULT '/src/assets/images/qabdiid_brand_mark_1794940828806.jpg',
      phone TEXT DEFAULT '+251 11 000 0000',
      email TEXT DEFAULT 'info@qabdiidbusiness.com',
      website TEXT DEFAULT 'www.qabdiidbusiness.com',
      address TEXT DEFAULT 'Addis Ababa, Ethiopia',
      tin TEXT DEFAULT '0000000000',
      vat_rate REAL NOT NULL DEFAULT 15,
      allow_negative_stock INTEGER NOT NULL DEFAULT 0,
      default_currency TEXT NOT NULL DEFAULT 'ETB',
      default_language TEXT NOT NULL DEFAULT 'en',
      receipt_header TEXT DEFAULT 'QABDIID BUSNESS 1',
      receipt_footer TEXT DEFAULT 'Thank you for your business! / Waad ku mahadsantahay adeegsigaaga!',
      sale_prefix TEXT NOT NULL DEFAULT 'SAL-',
      purchase_prefix TEXT NOT NULL DEFAULT 'PUR-',
      return_prefix TEXT NOT NULL DEFAULT 'RET-',
      invoice_seq_sale INTEGER NOT NULL DEFAULT 0,
      invoice_seq_purchase INTEGER NOT NULL DEFAULT 0,
      invoice_seq_return INTEGER NOT NULL DEFAULT 0,
      invoice_seq_expense INTEGER NOT NULL DEFAULT 0,
      invoice_seq_journal INTEGER NOT NULL DEFAULT 0,
      min_password_length INTEGER NOT NULL DEFAULT 6,
      require_2fa INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS currencies (
      code TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      symbol TEXT NOT NULL,
      decimal_places INTEGER NOT NULL DEFAULT 2,
      is_default INTEGER NOT NULL DEFAULT 0,
      exchange_rate_to_etb REAL NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS exchange_rate_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      currency_code TEXT NOT NULL,
      rate_to_etb REAL NOT NULL,
      changed_by TEXT NOT NULL,
      changed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL,
      phone TEXT DEFAULT '',
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL,
      permissions_json TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      two_factor_enabled INTEGER NOT NULL DEFAULT 0,
      two_factor_secret TEXT DEFAULT '',
      photo_url TEXT DEFAULT '',
      gender TEXT DEFAULT '',
      date_of_birth TEXT DEFAULT '',
      country TEXT DEFAULT '',
      address TEXT DEFAULT '',
      last_login_at TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      ip_info TEXT DEFAULT '',
      user_agent TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      record_id TEXT DEFAULT '',
      details TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS warehouses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      location TEXT DEFAULT '',
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      sku TEXT NOT NULL UNIQUE,
      barcode TEXT NOT NULL UNIQUE,
      category_id INTEGER,
      unit TEXT NOT NULL DEFAULT 'PC',
      purchase_price REAL NOT NULL DEFAULT 0,
      selling_price REAL NOT NULL DEFAULT 0,
      wholesale_price REAL NOT NULL DEFAULT 0,
      vat_rate REAL NOT NULL DEFAULT 15,
      current_stock REAL NOT NULL DEFAULT 0,
      min_stock REAL NOT NULL DEFAULT 5,
      warehouse_id INTEGER DEFAULT 1,
      expiry_date TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      description TEXT DEFAULT '',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
      FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      warehouse_id INTEGER NOT NULL DEFAULT 1,
      movement_type TEXT NOT NULL,
      quantity REAL NOT NULL,
      unit_cost REAL NOT NULL DEFAULT 0,
      reference_type TEXT DEFAULT '',
      reference_id TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      phone TEXT DEFAULT '',
      address TEXT DEFAULT '',
      opening_balance REAL NOT NULL DEFAULT 0,
      total_purchases REAL NOT NULL DEFAULT 0,
      total_paid REAL NOT NULL DEFAULT 0,
      outstanding_balance REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS customer_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER NOT NULL,
      sale_id INTEGER,
      amount REAL NOT NULL,
      currency TEXT NOT NULL DEFAULT 'ETB',
      exchange_rate REAL NOT NULL DEFAULT 1,
      amount_etb REAL NOT NULL,
      payment_method TEXT NOT NULL,
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      business_name TEXT NOT NULL,
      contact_person TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      address TEXT DEFAULT '',
      opening_balance REAL NOT NULL DEFAULT 0,
      total_purchases REAL NOT NULL DEFAULT 0,
      total_paid REAL NOT NULL DEFAULT 0,
      outstanding_balance REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS supplier_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER NOT NULL,
      purchase_id INTEGER,
      amount REAL NOT NULL,
      currency TEXT NOT NULL DEFAULT 'ETB',
      exchange_rate REAL NOT NULL DEFAULT 1,
      amount_etb REAL NOT NULL,
      payment_method TEXT NOT NULL,
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_number TEXT NOT NULL UNIQUE,
      sale_date TEXT NOT NULL,
      customer_id INTEGER,
      warehouse_id INTEGER NOT NULL DEFAULT 1,
      currency TEXT NOT NULL DEFAULT 'ETB',
      exchange_rate REAL NOT NULL DEFAULT 1,
      subtotal REAL NOT NULL DEFAULT 0,
      discount_amount REAL NOT NULL DEFAULT 0,
      vat_amount REAL NOT NULL DEFAULT 0,
      grand_total REAL NOT NULL DEFAULT 0,
      paid_amount REAL NOT NULL DEFAULT 0,
      balance_amount REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'Cash',
      split_details_json TEXT DEFAULT '{}',
      status TEXT NOT NULL DEFAULT 'Paid',
      notes TEXT DEFAULT '',
      created_by_id INTEGER,
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      sku TEXT NOT NULL,
      unit TEXT NOT NULL,
      quantity REAL NOT NULL,
      returned_qty REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL,
      cost_price REAL NOT NULL,
      discount_amount REAL NOT NULL DEFAULT 0,
      vat_rate REAL NOT NULL DEFAULT 15,
      vat_amount REAL NOT NULL DEFAULT 0,
      subtotal REAL NOT NULL,
      FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS sale_returns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_number TEXT NOT NULL UNIQUE,
      sale_id INTEGER NOT NULL,
      invoice_number TEXT NOT NULL,
      customer_id INTEGER,
      return_date TEXT NOT NULL,
      total_refund REAL NOT NULL,
      refund_method TEXT NOT NULL DEFAULT 'Cash',
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (sale_id) REFERENCES sales(id)
    );

    CREATE TABLE IF NOT EXISTS sale_return_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_id INTEGER NOT NULL,
      sale_item_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity REAL NOT NULL,
      unit_price REAL NOT NULL,
      vat_amount REAL NOT NULL DEFAULT 0,
      subtotal REAL NOT NULL,
      FOREIGN KEY (return_id) REFERENCES sale_returns(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_number TEXT NOT NULL UNIQUE,
      purchase_date TEXT NOT NULL,
      supplier_id INTEGER,
      warehouse_id INTEGER NOT NULL DEFAULT 1,
      currency TEXT NOT NULL DEFAULT 'ETB',
      exchange_rate REAL NOT NULL DEFAULT 1,
      subtotal REAL NOT NULL DEFAULT 0,
      discount_amount REAL NOT NULL DEFAULT 0,
      vat_amount REAL NOT NULL DEFAULT 0,
      grand_total REAL NOT NULL DEFAULT 0,
      paid_amount REAL NOT NULL DEFAULT 0,
      balance_amount REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'Cash',
      status TEXT NOT NULL DEFAULT 'Paid',
      notes TEXT DEFAULT '',
      created_by_id INTEGER,
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS purchase_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      sku TEXT NOT NULL,
      unit TEXT NOT NULL,
      quantity REAL NOT NULL,
      returned_qty REAL NOT NULL DEFAULT 0,
      purchase_price REAL NOT NULL,
      vat_rate REAL NOT NULL DEFAULT 15,
      vat_amount REAL NOT NULL DEFAULT 0,
      subtotal REAL NOT NULL,
      FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_returns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_number TEXT NOT NULL UNIQUE,
      purchase_id INTEGER NOT NULL,
      purchase_number TEXT NOT NULL,
      supplier_id INTEGER,
      return_date TEXT NOT NULL,
      total_refund REAL NOT NULL,
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (purchase_id) REFERENCES purchases(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_return_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      return_id INTEGER NOT NULL,
      purchase_item_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL,
      quantity REAL NOT NULL,
      purchase_price REAL NOT NULL,
      vat_amount REAL NOT NULL DEFAULT 0,
      subtotal REAL NOT NULL,
      FOREIGN KEY (return_id) REFERENCES purchase_returns(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      expense_code TEXT NOT NULL UNIQUE,
      expense_date TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      amount REAL NOT NULL,
      currency TEXT NOT NULL DEFAULT 'ETB',
      exchange_rate REAL NOT NULL DEFAULT 1,
      amount_etb REAL NOT NULL,
      payment_method TEXT NOT NULL DEFAULT 'Cash',
      receipt_ref TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      balance REAL NOT NULL DEFAULT 0,
      is_system INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS journal_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      entry_number TEXT NOT NULL UNIQUE,
      entry_date TEXT NOT NULL,
      reference_type TEXT DEFAULT '',
      reference_id TEXT DEFAULT '',
      description TEXT NOT NULL,
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS journal_lines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      journal_entry_id INTEGER NOT NULL,
      account_id INTEGER NOT NULL,
      debit REAL NOT NULL DEFAULT 0,
      credit REAL NOT NULL DEFAULT 0,
      FOREIGN KEY (journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
      FOREIGN KEY (account_id) REFERENCES accounts(id)
    );

    CREATE TABLE IF NOT EXISTS financial_periods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Open',
      closed_by TEXT DEFAULT '',
      closed_at TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title_en TEXT NOT NULL,
      title_so TEXT NOT NULL,
      message_en TEXT NOT NULL,
      message_so TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      reference_type TEXT DEFAULT '',
      reference_id TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS units (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      unit_name TEXT NOT NULL UNIQUE,
      short_name TEXT NOT NULL,
      description TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vat_rates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      percentage REAL NOT NULL DEFAULT 15,
      vat_type TEXT NOT NULL DEFAULT 'Standard',
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS expense_categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS opening_balance_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      party_type TEXT NOT NULL,
      party_id INTEGER NOT NULL,
      entry_type TEXT NOT NULL,
      amount REAL NOT NULL,
      entry_date TEXT NOT NULL,
      notes TEXT DEFAULT '',
      created_by TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  const ensureColumns = (table: string, cols: Array<[string, string]>) => {
    const existing = new Set(
      (db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>).map((c) => c.name)
    );
    for (const [col, def] of cols) {
      if (!existing.has(col)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def};`);
      }
    }
  };

  // Ensure new user profile & ERP extension columns exist on existing databases without altering existing data
  ensureColumns('users', [
    ['photo_url', "TEXT DEFAULT ''"],
    ['gender', "TEXT DEFAULT ''"],
    ['date_of_birth', "TEXT DEFAULT ''"],
    ['country', "TEXT DEFAULT ''"],
    ['address', "TEXT DEFAULT ''"],
  ]);
  ensureColumns('settings', [['favicon_url', "TEXT DEFAULT ''"]]);
  ensureColumns('products', [['product_code', "TEXT DEFAULT ''"]]);
  ensureColumns('customers', [
    ['customer_code', "TEXT DEFAULT ''"],
    ['email', "TEXT DEFAULT ''"],
  ]);
  ensureColumns('suppliers', [
    ['supplier_code', "TEXT DEFAULT ''"],
    ['email', "TEXT DEFAULT ''"],
  ]);
  ensureColumns('sale_returns', [
    ['reason', "TEXT DEFAULT ''"],
    ['status', "TEXT DEFAULT 'Completed'"],
  ]);
  ensureColumns('purchase_returns', [
    ['reason', "TEXT DEFAULT ''"],
    ['status', "TEXT DEFAULT 'Completed'"],
  ]);
  ensureColumns('purchases', [['supplier_invoice_no', "TEXT DEFAULT ''"]]);
  ensureColumns('expenses', [
    ['title', "TEXT DEFAULT ''"],
    ['attachment_url', "TEXT DEFAULT ''"],
  ]);

  // Backfill friendly defaults on existing rows if empty
  db.exec(`
    UPDATE products SET product_code = sku WHERE COALESCE(product_code, '') = '';
    UPDATE expenses SET title = category WHERE COALESCE(title, '') = '';
    UPDATE customers SET customer_code = 'CUS-' || printf('%04d', id) WHERE COALESCE(customer_code, '') = '';
    UPDATE suppliers SET supplier_code = 'SUP-' || printf('%04d', id) WHERE COALESCE(supplier_code, '') = '';
    UPDATE users SET permissions_json = '${JSON.stringify(ROLE_DEFAULT_PERMISSIONS['Super Administrator'])}' WHERE role IN ('Super Administrator', 'Administrator');
  `);

  const now = addisDateTime();

  // Bootstrap settings once
  const settingsRow = db.prepare('SELECT id FROM settings WHERE id = 1').get();
  if (!settingsRow) {
    db.prepare(`
      INSERT INTO settings (id, business_name, system_name, updated_at)
      VALUES (1, 'QABDIID BUSNESS 1', 'QABDIID BUSNESS 1', ?)
    `).run(now);
  }

  // Bootstrap currencies
  const currencyCount = (db.prepare('SELECT COUNT(*) as c FROM currencies').get() as { c: number }).c;
  if (currencyCount === 0) {
    db.prepare(`
      INSERT INTO currencies (code, name, symbol, decimal_places, is_default, exchange_rate_to_etb, updated_at)
      VALUES
        ('ETB', 'Ethiopian Birr', 'ETB', 2, 1, 1.0, ?),
        ('USD', 'US Dollar', '$', 2, 0, 125.0, ?)
    `).run(now, now);
    db.prepare(`
      INSERT INTO exchange_rate_history (currency_code, rate_to_etb, changed_by, changed_at)
      VALUES ('USD', 125.0, 'System', ?)
    `).run(now);
  }

  // Bootstrap warehouses
  const whCount = (db.prepare('SELECT COUNT(*) as c FROM warehouses').get() as { c: number }).c;
  if (whCount === 0) {
    db.prepare(`
      INSERT INTO warehouses (name, location, is_default, created_at)
      VALUES ('Main Warehouse', 'Addis Ababa HQ', 1, ?)
    `).run(now);
  }

  // Bootstrap categories
  const catCount = (db.prepare('SELECT COUNT(*) as c FROM categories').get() as { c: number }).c;
  if (catCount === 0) {
    const insertCat = db.prepare('INSERT INTO categories (name, description, created_at) VALUES (?, ?, ?)');
    insertCat.run('Electronics', 'Consumer electronics, audio, accessories and hardware', now);
    insertCat.run('General', 'Supermarket, groceries and everyday commercial goods', now);
    insertCat.run('Stationery', 'Office supplies, notebooks, pens and paper products', now);
    insertCat.run('Wholesale Bulk', 'Carton and wholesale trade items', now);
  }

  // Bootstrap units
  const unitCount = (db.prepare('SELECT COUNT(*) as c FROM units').get() as { c: number }).c;
  if (unitCount === 0) {
    const insertUnit = db.prepare('INSERT INTO units (unit_name, short_name, description, created_at) VALUES (?, ?, ?, ?)');
    insertUnit.run('Piece', 'PC', 'Individual retail unit / piece', now);
    insertUnit.run('Box', 'Box', 'Boxed pack', now);
    insertUnit.run('Carton', 'Carton', 'Standard wholesale carton', now);
    insertUnit.run('Kilogram', 'KG', 'Weight measured in kilograms', now);
    insertUnit.run('Litre', 'L', 'Liquid volume measured in litres', now);
    insertUnit.run('Meter', 'M', 'Length measured in meters', now);
    insertUnit.run('Wholesale', 'JM', 'Wholesale bundle / jumlo', now);
  }

  // Bootstrap VAT rates
  const vatCount = (db.prepare('SELECT COUNT(*) as c FROM vat_rates').get() as { c: number }).c;
  if (vatCount === 0) {
    const insertVat = db.prepare('INSERT INTO vat_rates (name, percentage, vat_type, is_default, created_at) VALUES (?, ?, ?, ?, ?)');
    insertVat.run('Standard VAT', 15, 'Standard', 1, now);
    insertVat.run('Zero-Rated', 0, 'Zero-Rated', 0, now);
    insertVat.run('VAT Exempt', 0, 'Exempt', 0, now);
  }

  // Bootstrap expense categories
  const expCatCount = (db.prepare('SELECT COUNT(*) as c FROM expense_categories').get() as { c: number }).c;
  if (expCatCount === 0) {
    const insertExpCat = db.prepare('INSERT INTO expense_categories (name, description, created_at) VALUES (?, ?, ?)');
    insertExpCat.run('Rent', 'Shop, office, or warehouse rental payments', now);
    insertExpCat.run('Electricity', 'Monthly electricity and power bills', now);
    insertExpCat.run('Salary', 'Staff wages, salaries and allowances', now);
    insertExpCat.run('Transport', 'Delivery, fuel and logistics costs', now);
    insertExpCat.run('Internet', 'Internet, telecom and cloud connectivity', now);
    insertExpCat.run('Utilities', 'Water and general facility utilities', now);
    insertExpCat.run('Maintenance', 'Repairs, equipment servicing and upkeep', now);
    insertExpCat.run('General Expenses', 'Miscellaneous operating expenses', now);
  }

  // Bootstrap Chart of Accounts
  const acctCount = (db.prepare('SELECT COUNT(*) as c FROM accounts').get() as { c: number }).c;
  if (acctCount === 0) {
    const insertAcct = db.prepare('INSERT INTO accounts (code, name, type, balance, is_system) VALUES (?, ?, ?, 0, 1)');
    const defaultAccounts = [
      ['1000', 'Cash on Hand', 'Asset'],
      ['1010', 'Bank Account', 'Asset'],
      ['1020', 'Mobile Money Wallet', 'Asset'],
      ['1100', 'Accounts Receivable', 'Asset'],
      ['1200', 'Inventory Asset', 'Asset'],
      ['1300', 'VAT Input Receivable', 'Asset'],
      ['2000', 'Accounts Payable', 'Liability'],
      ['2100', 'VAT Payable', 'Liability'],
      ['3000', "Owner's Equity", 'Equity'],
      ['4000', 'Sales Revenue', 'Revenue'],
      ['4100', 'Sales Returns & Allowances', 'Revenue'],
      ['4200', 'Other Income', 'Revenue'],
      ['5000', 'Cost of Goods Sold', 'Expense'],
      ['6000', 'Operating Expenses', 'Expense'],
    ];
    for (const [code, name, type] of defaultAccounts) {
      insertAcct.run(code, name, type);
    }
  }

  // Bootstrap Financial Period
  const fpCount = (db.prepare('SELECT COUNT(*) as c FROM financial_periods').get() as { c: number }).c;
  if (fpCount === 0) {
    db.prepare(`
      INSERT INTO financial_periods (name, start_date, end_date, status)
      VALUES ('FY 2026', '2026-01-01', '2026-12-31', 'Open')
    `).run();
  }

  // Bootstrap initial system administrator & walk-in customer on fresh DB
  const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  if (userCount === 0) {
    const insertUser = db.prepare(`
      INSERT INTO users (first_name, last_name, username, email, phone, password_hash, role, permissions_json, is_active, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);
    insertUser.run(
      'Abdi',
      'Qabdiid',
      'admin',
      'admin@qabdiidbusiness.com',
      '+251 911 000 001',
      hashPassword('admin123'),
      'Super Administrator',
      JSON.stringify(ROLE_DEFAULT_PERMISSIONS['Super Administrator']),
      now
    );
    insertUser.run(
      'Halima',
      'Hassan',
      'cashier',
      'cashier@qabdiidbusiness.com',
      '+251 911 000 002',
      hashPassword('cashier123'),
      'Cashier',
      JSON.stringify(ROLE_DEFAULT_PERMISSIONS['Cashier']),
      now
    );

    const custCount = (db.prepare('SELECT COUNT(*) as c FROM customers').get() as { c: number }).c;
    if (custCount === 0) {
      db.prepare(`
        INSERT INTO customers (full_name, phone, address, opening_balance, total_purchases, total_paid, outstanding_balance, created_at)
        VALUES ('Walk-In Customer', '', 'Counter Sale', 0, 0, 0, 0, ?)
      `).run(now);
    }

    const supCount = (db.prepare('SELECT COUNT(*) as c FROM suppliers').get() as { c: number }).c;
    if (supCount === 0) {
      db.prepare(`
        INSERT INTO suppliers (business_name, contact_person, phone, address, opening_balance, total_purchases, total_paid, outstanding_balance, created_at)
        VALUES ('Horn Trade Distribution', 'Mohamed Ali', '+251 11 555 0100', 'Merkato Commercial Zone', 0, 0, 0, 0, ?)
      `).run(now);
    }

    // Starter catalog products (clean initial inventory catalog with zero fake sales/purchases)
    const prodCount = (db.prepare('SELECT COUNT(*) as c FROM products').get() as { c: number }).c;
    if (prodCount === 0) {
      const insertProd = db.prepare(`
        INSERT INTO products (name, sku, barcode, category_id, unit, purchase_price, selling_price, wholesale_price, vat_rate, current_stock, min_stock, warehouse_id, expiry_date, image_url, description, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, 1, ?, ?)
      `);
      insertProd.run(
        'Wireless Studio Headphones Pro',
        'ELC-1001',
        '629100100101',
        1,
        'PC',
        2800,
        4200,
        3800,
        15,
        24,
        5,
        '',
        '/src/assets/images/product_electronics_1794940830166.jpg',
        'Active noise cancelling wireless headphones with charging dock',
        now,
        now
      );
      insertProd.run(
        'Artisan Arabica Coffee Beans 1kg',
        'GEN-2001',
        '629100200101',
        2,
        'KG',
        650,
        980,
        850,
        15,
        45,
        10,
        '2027-06-30',
        '/src/assets/images/product_groceries_1794940830920.jpg',
        'Single origin roasted Ethiopian highland coffee beans 1kg pack',
        now,
        now
      );
      insertProd.run(
        'Extra Virgin Olive Oil 750ml',
        'GEN-2002',
        '629100200102',
        2,
        'L',
        820,
        1250,
        1100,
        15,
        30,
        8,
        '2027-09-15',
        '/src/assets/images/product_groceries_1794940830920.jpg',
        'Cold-pressed premium olive oil glass bottle',
        now,
        now
      );
      insertProd.run(
        'Executive Hardcover Ledger Set',
        'STN-3001',
        '629100300101',
        3,
        'Box',
        420,
        680,
        580,
        15,
        36,
        6,
        '',
        '/src/assets/images/product_stationery_1794940832585.jpg',
        'Executive notebook and metal pen stationery gift box',
        now,
        now
      );
    }
  }
}
