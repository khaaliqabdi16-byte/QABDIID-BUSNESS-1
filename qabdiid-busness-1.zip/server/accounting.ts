import { db, addisDateTime, addisDate } from './db.ts';

export interface JournalLineInput {
  accountCode: string;
  debit: number;
  credit: number;
}

export function getNextSequence(field: 'invoice_seq_sale' | 'invoice_seq_purchase' | 'invoice_seq_return' | 'invoice_seq_expense' | 'invoice_seq_journal'): number {
  const row = db.prepare(`SELECT ${field} as seq FROM settings WHERE id = 1`).get() as { seq: number };
  const next = (row?.seq ?? 0) + 1;
  db.prepare(`UPDATE settings SET ${field} = ? WHERE id = 1`).run(next);
  return next;
}

export function formatCode(prefix: string, seq: number): string {
  return `${prefix}${String(seq).padStart(6, '0')}`;
}

export function postJournalEntry(params: {
  entryDate?: string;
  referenceType: string;
  referenceId: string;
  description: string;
  createdBy: string;
  lines: JournalLineInput[];
}): number {
  const totalDebit = params.lines.reduce((s, l) => s + Number(l.debit || 0), 0);
  const totalCredit = params.lines.reduce((s, l) => s + Number(l.credit || 0), 0);

  if (Math.abs(totalDebit - totalCredit) > 0.05) {
    throw new Error(`Unbalanced journal entry: Debit ${totalDebit.toFixed(2)} != Credit ${totalCredit.toFixed(2)}`);
  }

  const validLines = params.lines.filter((l) => Number(l.debit) > 0.0001 || Number(l.credit) > 0.0001);
  if (validLines.length === 0) return 0;

  const seq = getNextSequence('invoice_seq_journal');
  const entryNumber = formatCode('JRN-', seq);
  const now = addisDateTime();
  const entryDate = params.entryDate || addisDate();

  const res = db.prepare(`
    INSERT INTO journal_entries (entry_number, entry_date, reference_type, reference_id, description, created_by, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(entryNumber, entryDate, params.referenceType, params.referenceId, params.description, params.createdBy, now);

  const entryId = Number(res.lastInsertRowid);
  const findAcct = db.prepare('SELECT id, type FROM accounts WHERE code = ?');
  const insertLine = db.prepare('INSERT INTO journal_lines (journal_entry_id, account_id, debit, credit) VALUES (?, ?, ?, ?)');
  const updateBalance = db.prepare('UPDATE accounts SET balance = balance + ? WHERE id = ?');

  for (const line of validLines) {
    const acct = findAcct.get(line.accountCode) as { id: number; type: string } | undefined;
    if (!acct) {
      throw new Error(`Account code ${line.accountCode} not found`);
    }
    const debit = Math.round(line.debit * 100) / 100;
    const credit = Math.round(line.credit * 100) / 100;
    insertLine.run(entryId, acct.id, debit, credit);

    const delta = acct.type === 'Asset' || acct.type === 'Expense' ? debit - credit : credit - debit;
    updateBalance.run(delta, acct.id);
  }

  return entryId;
}

export function paymentAccountCode(method: string): string {
  switch (method) {
    case 'Card':
    case 'Bank Transfer':
      return '1010';
    case 'Mobile Money':
      return '1020';
    case 'Credit':
    case 'Credit/Debt':
      return '1100';
    default:
      return '1000';
  }
}

export function createNotification(params: {
  type: string;
  titleEn: string;
  titleSo: string;
  messageEn: string;
  messageSo: string;
  referenceType?: string;
  referenceId?: string;
}): void {
  db.prepare(`
    INSERT INTO notifications (type, title_en, title_so, message_en, message_so, reference_type, reference_id, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    params.type,
    params.titleEn,
    params.titleSo,
    params.messageEn,
    params.messageSo,
    params.referenceType || '',
    params.referenceId || '',
    addisDateTime()
  );
}

export function checkLowStockNotification(productId: number): void {
  const prod = db.prepare('SELECT id, name, sku, current_stock, min_stock FROM products WHERE id = ?').get(productId) as
    | { id: number; name: string; sku: string; current_stock: number; min_stock: number }
    | undefined;
  if (!prod) return;
  if (prod.current_stock <= prod.min_stock) {
    createNotification({
      type: 'LOW_STOCK',
      titleEn: `Low Stock Alert: ${prod.name}`,
      titleSo: `Digniin Kayd Yar: ${prod.name}`,
      messageEn: `${prod.name} (${prod.sku}) is at ${prod.current_stock} units (minimum: ${prod.min_stock}).`,
      messageSo: `${prod.name} (${prod.sku}) waxa uu marayaa ${prod.current_stock} xabo (ugu yaraan: ${prod.min_stock}).`,
      referenceType: 'product',
      referenceId: String(prod.id),
    });
  }
}

export function logAudit(params: {
  userId?: number | null;
  username: string;
  action: string;
  module: string;
  recordId?: string;
  details?: string;
}): void {
  db.prepare(`
    INSERT INTO audit_logs (user_id, username, action, module, record_id, details, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    params.userId ?? null,
    params.username,
    params.action,
    params.module,
    params.recordId || '',
    params.details || '',
    addisDateTime()
  );
}
